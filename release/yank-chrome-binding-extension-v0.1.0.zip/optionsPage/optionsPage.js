"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill.default.runtime.sendMessage(message);
  }

  // src/lib/adapters/runtime/yankApi.ts
  async function expectOk(response) {
    if (response.ok) return;
    throw new Error(response.reason);
  }
  async function getSettings() {
    const response = await sendRuntimeMessage({ type: "GET_SETTINGS" });
    if (!response.ok || !("settings" in response)) {
      throw new Error(response.ok ? "Invalid GET_SETTINGS response" : response.reason);
    }
    return response.settings;
  }
  async function patchSettings(patch) {
    const response = await sendRuntimeMessage({ type: "PATCH_SETTINGS", patch });
    await expectOk(response);
  }

  // src/lib/common/utils/shortcuts.ts
  var MODIFIER_ALIASES = {
    ctrl: "Ctrl",
    control: "Ctrl",
    alt: "Alt",
    option: "Alt",
    shift: "Shift",
    meta: "Meta",
    cmd: "Meta",
    command: "Meta",
    win: "Meta",
    super: "Meta"
  };
  var CANONICAL_SPECIAL_KEYS = {
    "`": "Backquote",
    backquote: "Backquote",
    enter: "Enter",
    return: "Enter",
    esc: "Escape",
    escape: "Escape",
    tab: "Tab",
    space: "Space",
    spacebar: "Space",
    arrowup: "ArrowUp",
    arrowdown: "ArrowDown",
    arrowleft: "ArrowLeft",
    arrowright: "ArrowRight",
    backspace: "Backspace",
    delete: "Delete",
    home: "Home",
    end: "End",
    pageup: "PageUp",
    pagedown: "PageDown",
    insert: "Insert"
  };
  var EDITABLE_MODIFIER_KEYS = /* @__PURE__ */ new Set(["Shift", "Control", "Alt", "Meta", "AltGraph"]);
  function normalizeKeyToken(token) {
    const trimmed = token.trim();
    if (!trimmed) return null;
    const lower = trimmed.toLowerCase();
    if (lower in CANONICAL_SPECIAL_KEYS) {
      return CANONICAL_SPECIAL_KEYS[lower];
    }
    const fnKeyMatch = lower.match(/^f(\d{1,2})$/);
    if (fnKeyMatch) {
      const num = Number.parseInt(fnKeyMatch[1], 10);
      if (Number.isFinite(num) && num >= 1 && num <= 24) {
        return `F${num}`;
      }
    }
    const digitCodeMatch = lower.match(/^digit(\d)$/);
    if (digitCodeMatch) return digitCodeMatch[1];
    const keyCodeMatch = lower.match(/^key([a-z])$/);
    if (keyCodeMatch) return keyCodeMatch[1].toUpperCase();
    if (trimmed.length === 1) {
      if (/^[a-z]$/i.test(trimmed)) return trimmed.toUpperCase();
      return trimmed;
    }
    if (/^[a-z][a-z0-9]*$/i.test(trimmed)) {
      return trimmed[0].toUpperCase() + trimmed.slice(1);
    }
    return null;
  }
  function normalizeShortcutString(input) {
    const raw = input.trim();
    if (!raw) return "";
    const tokens = raw.split("+").map((token) => token.trim()).filter(Boolean);
    if (tokens.length === 0) return "";
    let keyToken = null;
    let ctrl = false;
    let alt = false;
    let shift = false;
    let meta = false;
    for (const token of tokens) {
      const lower = token.toLowerCase();
      const modifier = MODIFIER_ALIASES[lower];
      if (modifier) {
        if (modifier === "Ctrl") ctrl = true;
        if (modifier === "Alt") alt = true;
        if (modifier === "Shift") shift = true;
        if (modifier === "Meta") meta = true;
        continue;
      }
      const normalizedKey = normalizeKeyToken(token);
      if (!normalizedKey) return "";
      if (keyToken) return "";
      keyToken = normalizedKey;
    }
    if (!keyToken) return "";
    const output = [];
    if (ctrl) output.push("Ctrl");
    if (alt) output.push("Alt");
    if (shift) output.push("Shift");
    if (meta) output.push("Meta");
    output.push(keyToken);
    return output.join("+");
  }
  function eventKeyToToken(event) {
    if (event.code === "Backquote" || event.key === "`") return "Backquote";
    if (event.code === "Space" || event.key === " ") return "Space";
    const key = event.key;
    if (!key) return null;
    if (EDITABLE_MODIFIER_KEYS.has(key)) return null;
    const lower = key.toLowerCase();
    if (lower in CANONICAL_SPECIAL_KEYS) {
      return CANONICAL_SPECIAL_KEYS[lower];
    }
    if (key.length === 1) {
      if (/^[a-z]$/i.test(key)) return key.toUpperCase();
      return key;
    }
    return normalizeKeyToken(key);
  }
  function keyboardEventToShortcutString(event) {
    const keyToken = eventKeyToToken(event);
    if (!keyToken) return "";
    const parts = [];
    if (event.ctrlKey) parts.push("Ctrl");
    if (event.altKey) parts.push("Alt");
    if (event.shiftKey) parts.push("Shift");
    if (event.metaKey) parts.push("Meta");
    parts.push(keyToken);
    return parts.join("+");
  }

  // src/entryPoints/optionsPage/optionsPage.ts
  var SHORTCUT_INPUT_IDS = [
    "shortcutSwitchToAutoCopy",
    "shortcutJsonToolingPrettyPrint",
    "shortcutJsonToolingPathCopy",
    "shortcutJsonToolingMarkdownTable",
    "shortcutCopyPageUrl",
    "shortcutCopyCleanCodeBlock",
    "shortcutCopyAsFetch",
    "shortcutCopyAsCurl"
  ];
  var SHORTCUT_FIELD_MAP = {
    shortcutSwitchToAutoCopy: "switchToAutoCopy",
    shortcutJsonToolingPrettyPrint: "jsonToolingPrettyPrint",
    shortcutJsonToolingPathCopy: "jsonToolingPathCopy",
    shortcutJsonToolingMarkdownTable: "jsonToolingMarkdownTable",
    shortcutCopyPageUrl: "copyPageUrl",
    shortcutCopyCleanCodeBlock: "copyCleanCodeBlock",
    shortcutCopyAsFetch: "copyAsFetch",
    shortcutCopyAsCurl: "copyAsCurl"
  };
  var SHORTCUT_LABELS = {
    shortcutSwitchToAutoCopy: "Toggle Auto-Copy on/off",
    shortcutJsonToolingPrettyPrint: "Toggle JSON Tools: Pretty Print",
    shortcutJsonToolingPathCopy: "Toggle JSON Tools: Path Copy",
    shortcutJsonToolingMarkdownTable: "Toggle JSON Tools: Markdown Table",
    shortcutCopyPageUrl: "Copy current page URL",
    shortcutCopyCleanCodeBlock: "Copy clean code block",
    shortcutCopyAsFetch: "Copy as Fetch",
    shortcutCopyAsCurl: "Copy as cURL"
  };
  var SHORTCUT_FIELD_LABELS = {
    switchToAutoCopy: SHORTCUT_LABELS.shortcutSwitchToAutoCopy,
    jsonToolingPrettyPrint: SHORTCUT_LABELS.shortcutJsonToolingPrettyPrint,
    jsonToolingPathCopy: SHORTCUT_LABELS.shortcutJsonToolingPathCopy,
    jsonToolingMarkdownTable: SHORTCUT_LABELS.shortcutJsonToolingMarkdownTable,
    copyPageUrl: SHORTCUT_LABELS.shortcutCopyPageUrl,
    copyCleanCodeBlock: SHORTCUT_LABELS.shortcutCopyCleanCodeBlock,
    copyAsFetch: SHORTCUT_LABELS.shortcutCopyAsFetch,
    copyAsCurl: SHORTCUT_LABELS.shortcutCopyAsCurl
  };
  var RESERVED_HELP_MENU_SHORTCUT = "Alt+M";
  function resolveJsonToolingMode(settings) {
    if (settings.prettyPrintEnabled) return "mode1";
    if (settings.decorateJsonBlocks) return "mode2";
    if (settings.tableFromArrayEnabled) return "mode3";
    return "off";
  }
  function buildJsonToolingModePatch(current, mode) {
    return {
      ...current,
      prettyPrintEnabled: mode === "mode1",
      decorateJsonBlocks: mode === "mode2",
      tableFromArrayEnabled: mode === "mode3"
    };
  }
  function byId(id) {
    return document.getElementById(id);
  }
  function collectShortcutRefs() {
    const refs = {};
    for (const id of SHORTCUT_INPUT_IDS) {
      refs[id] = byId(id);
    }
    return refs;
  }
  function collectFormRefs() {
    return {
      urlShowToast: byId("urlShowToast"),
      urlToastDismissMs: byId("urlToastDismissMs"),
      autoCopyEnabled: byId("autoCopyEnabled"),
      plainTextMode: byId("plainTextMode"),
      appendMode: byId("appendMode"),
      sourceTagMode: byId("sourceTagMode"),
      showSelectionCountBadge: byId("showSelectionCountBadge"),
      appendSeparator: byId("appendSeparator"),
      siteRuleMode: byId("siteRuleMode"),
      siteRules: byId("siteRules"),
      jsonToolingModeSelect: byId("jsonToolingModeSelect"),
      rootPathPrefix: byId("rootPathPrefix"),
      shortcutInputs: collectShortcutRefs()
    };
  }
  function showStatus(message, type = "success", dismissMs = 2200) {
    const statusBar = byId("statusBar");
    statusBar.textContent = message;
    statusBar.className = `status-bar visible${type === "error" ? " error" : ""}`;
    if (dismissMs <= 0) return;
    window.setTimeout(() => {
      statusBar.classList.remove("visible");
    }, dismissMs);
  }
  function fillForm(settings, refs) {
    refs.urlShowToast.checked = settings.urlCopy.showToast;
    refs.urlToastDismissMs.value = String(settings.urlCopy.toastDismissMs);
    refs.autoCopyEnabled.checked = settings.autoCopy.enabled;
    refs.plainTextMode.checked = settings.autoCopy.plainTextMode;
    refs.appendMode.checked = settings.autoCopy.appendMode;
    refs.sourceTagMode.checked = settings.autoCopy.sourceTagMode;
    refs.showSelectionCountBadge.checked = settings.autoCopy.showSelectionCountBadge;
    refs.appendSeparator.value = settings.autoCopy.appendSeparator;
    refs.siteRuleMode.value = settings.autoCopy.siteRuleMode;
    refs.siteRules.value = settings.autoCopy.siteRules.join("\n");
    refs.jsonToolingModeSelect.value = resolveJsonToolingMode(settings.jsonTooling);
    refs.rootPathPrefix.value = settings.jsonTooling.rootPathPrefix;
    for (const id of SHORTCUT_INPUT_IDS) {
      const field = SHORTCUT_FIELD_MAP[id];
      refs.shortcutInputs[id].value = settings.shortcuts[field];
    }
  }
  function collectShortcutPatch(refs, current) {
    const next = { ...current.shortcuts };
    for (const id of SHORTCUT_INPUT_IDS) {
      const input = refs.shortcutInputs[id];
      const raw = input.value.trim();
      if (!raw) {
        next[SHORTCUT_FIELD_MAP[id]] = "";
        continue;
      }
      const normalized = normalizeShortcutString(raw);
      if (!normalized) {
        throw new Error(`Invalid shortcut: ${SHORTCUT_LABELS[id]}`);
      }
      next[SHORTCUT_FIELD_MAP[id]] = normalized;
    }
    const usedByShortcut = /* @__PURE__ */ new Map();
    const shortcutFields = Object.keys(next);
    for (const field of shortcutFields) {
      const value = next[field];
      if (!value) continue;
      const existing = usedByShortcut.get(value);
      if (existing) {
        existing.push(field);
      } else {
        usedByShortcut.set(value, [field]);
      }
    }
    const duplicateDetails = [];
    for (const [shortcut, fields] of usedByShortcut.entries()) {
      if (fields.length < 2) continue;
      const labels = fields.map((field) => SHORTCUT_FIELD_LABELS[field]).join(" + ");
      duplicateDetails.push(`${shortcut} -> ${labels}`);
    }
    if (duplicateDetails.length > 0) {
      throw new Error(`Duplicate shortcuts are not allowed: ${duplicateDetails.join("; ")}`);
    }
    const conflictingFields = Object.keys(next).filter((field) => next[field] === RESERVED_HELP_MENU_SHORTCUT);
    if (conflictingFields.length > 0) {
      const labels = conflictingFields.map((field) => SHORTCUT_FIELD_LABELS[field]).join(" + ");
      throw new Error(
        `${RESERVED_HELP_MENU_SHORTCUT} is reserved for Help Menu toggle. Reassign: ${labels}`
      );
    }
    return next;
  }
  function collectPatch(refs, current) {
    const toastDismiss = Number.parseInt(refs.urlToastDismissMs.value, 10);
    const shortcuts = collectShortcutPatch(refs, current);
    const modeCandidate = refs.jsonToolingModeSelect.value;
    const mode = modeCandidate === "mode1" || modeCandidate === "mode2" || modeCandidate === "mode3" ? modeCandidate : "off";
    const jsonToolingModePatch = buildJsonToolingModePatch(current.jsonTooling, mode);
    return {
      urlCopy: {
        ...current.urlCopy,
        showToast: refs.urlShowToast.checked,
        toastDismissMs: Number.isFinite(toastDismiss) ? Math.max(200, toastDismiss) : current.urlCopy.toastDismissMs
      },
      autoCopy: {
        ...current.autoCopy,
        enabled: refs.autoCopyEnabled.checked,
        plainTextMode: refs.plainTextMode.checked,
        appendMode: refs.appendMode.checked,
        sourceTagMode: refs.sourceTagMode.checked,
        showSelectionCountBadge: refs.showSelectionCountBadge.checked,
        appendSeparator: refs.appendSeparator.value,
        siteRuleMode: refs.siteRuleMode.value,
        siteRules: refs.siteRules.value.split(/\r?\n/).map((rule) => rule.trim()).filter(Boolean)
      },
      jsonTooling: {
        ...jsonToolingModePatch,
        rootPathPrefix: refs.rootPathPrefix.value.trim() || "response.data"
      },
      shortcuts
    };
  }
  document.addEventListener("DOMContentLoaded", async () => {
    const refs = collectFormRefs();
    let settings = await getSettings();
    fillForm(settings, refs);
    let captureTarget = null;
    let captureButton = null;
    let captureOriginalLabel = "";
    function stopCapture() {
      if (!captureButton) {
        captureTarget = null;
        return;
      }
      captureButton.textContent = captureOriginalLabel;
      captureButton.classList.remove("active-capture");
      captureButton = null;
      captureTarget = null;
    }
    document.querySelectorAll(".capture-btn").forEach((button) => {
      button.addEventListener("click", () => {
        const targetId = button.dataset.shortcutId;
        if (!targetId || !(targetId in SHORTCUT_FIELD_MAP)) return;
        if (captureButton === button) {
          stopCapture();
          showStatus("Shortcut capture canceled.");
          return;
        }
        stopCapture();
        captureTarget = targetId;
        captureButton = button;
        captureOriginalLabel = button.textContent || "Capture";
        captureButton.textContent = "Press keys...";
        captureButton.classList.add("active-capture");
        showStatus(`Capturing ${SHORTCUT_LABELS[targetId]}. Press Esc to cancel.`, "success", 0);
      });
    });
    document.querySelectorAll(".clear-btn").forEach((button) => {
      button.addEventListener("click", () => {
        const targetId = button.dataset.shortcutId;
        if (!targetId || !(targetId in SHORTCUT_FIELD_MAP)) return;
        refs.shortcutInputs[targetId].value = "";
        stopCapture();
        showStatus(`Cleared: ${SHORTCUT_LABELS[targetId]}.`);
      });
    });
    document.addEventListener("keydown", (event) => {
      if (!captureTarget) return;
      event.preventDefault();
      event.stopPropagation();
      if (event.key === "Escape" && !event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey) {
        stopCapture();
        showStatus("Shortcut capture canceled.");
        return;
      }
      const shortcut = keyboardEventToShortcutString(event);
      if (!shortcut) return;
      refs.shortcutInputs[captureTarget].value = shortcut;
      const label = SHORTCUT_LABELS[captureTarget];
      stopCapture();
      showStatus(`Captured ${label}: ${shortcut}`);
    }, true);
    for (const id of SHORTCUT_INPUT_IDS) {
      refs.shortcutInputs[id].addEventListener("blur", () => {
        const raw = refs.shortcutInputs[id].value.trim();
        if (!raw) {
          refs.shortcutInputs[id].value = "";
          return;
        }
        const normalized = normalizeShortcutString(raw);
        if (normalized) {
          refs.shortcutInputs[id].value = normalized;
        }
      });
    }
    const saveBtn = byId("saveBtn");
    saveBtn.addEventListener("click", async () => {
      try {
        const patch = collectPatch(refs, settings);
        await patchSettings(patch);
        settings = await getSettings();
        fillForm(settings, refs);
        stopCapture();
        showStatus("Settings saved.", "success");
      } catch (error) {
        stopCapture();
        showStatus(error instanceof Error ? error.message : "Save failed", "error");
      }
    });
    const reloadBtn = byId("reloadBtn");
    reloadBtn.addEventListener("click", async () => {
      settings = await getSettings();
      fillForm(settings, refs);
      stopCapture();
      showStatus("Reloaded.", "success");
    });
  });
})();
