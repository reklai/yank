"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill.default.runtime.sendMessage(message);
  }

  // src/lib/adapters/runtime/yankApi.ts
  async function expectOk(response) {
    if (response.ok) return;
    throw new Error(response.reason);
  }
  async function getSettings() {
    const response = await sendRuntimeMessage({ type: "GET_SETTINGS" });
    if (!response.ok || !("settings" in response)) {
      throw new Error(response.ok ? "Invalid GET_SETTINGS response" : response.reason);
    }
    return response.settings;
  }
  async function patchSettings(patch) {
    const response = await sendRuntimeMessage({ type: "PATCH_SETTINGS", patch });
    await expectOk(response);
  }
  async function notifyContentReady() {
    const response = await sendRuntimeMessage({ type: "CONTENT_READY" });
    await expectOk(response);
  }

  // src/lib/common/utils/shortcuts.ts
  var MODIFIER_ALIASES = {
    ctrl: "Ctrl",
    control: "Ctrl",
    alt: "Alt",
    option: "Alt",
    shift: "Shift",
    meta: "Meta",
    cmd: "Meta",
    command: "Meta",
    win: "Meta",
    super: "Meta"
  };
  var CANONICAL_SPECIAL_KEYS = {
    "`": "Backquote",
    backquote: "Backquote",
    enter: "Enter",
    return: "Enter",
    esc: "Escape",
    escape: "Escape",
    tab: "Tab",
    space: "Space",
    spacebar: "Space",
    arrowup: "ArrowUp",
    arrowdown: "ArrowDown",
    arrowleft: "ArrowLeft",
    arrowright: "ArrowRight",
    backspace: "Backspace",
    delete: "Delete",
    home: "Home",
    end: "End",
    pageup: "PageUp",
    pagedown: "PageDown",
    insert: "Insert"
  };
  var EDITABLE_MODIFIER_KEYS = /* @__PURE__ */ new Set(["Shift", "Control", "Alt", "Meta", "AltGraph"]);
  function normalizeKeyToken(token) {
    const trimmed = token.trim();
    if (!trimmed) return null;
    const lower = trimmed.toLowerCase();
    if (lower in CANONICAL_SPECIAL_KEYS) {
      return CANONICAL_SPECIAL_KEYS[lower];
    }
    const fnKeyMatch = lower.match(/^f(\d{1,2})$/);
    if (fnKeyMatch) {
      const num = Number.parseInt(fnKeyMatch[1], 10);
      if (Number.isFinite(num) && num >= 1 && num <= 24) {
        return `F${num}`;
      }
    }
    const digitCodeMatch = lower.match(/^digit(\d)$/);
    if (digitCodeMatch) return digitCodeMatch[1];
    const keyCodeMatch = lower.match(/^key([a-z])$/);
    if (keyCodeMatch) return keyCodeMatch[1].toUpperCase();
    if (trimmed.length === 1) {
      if (/^[a-z]$/i.test(trimmed)) return trimmed.toUpperCase();
      return trimmed;
    }
    if (/^[a-z][a-z0-9]*$/i.test(trimmed)) {
      return trimmed[0].toUpperCase() + trimmed.slice(1);
    }
    return null;
  }
  function normalizeShortcutString(input) {
    const raw = input.trim();
    if (!raw) return "";
    const tokens = raw.split("+").map((token) => token.trim()).filter(Boolean);
    if (tokens.length === 0) return "";
    let keyToken = null;
    let ctrl = false;
    let alt = false;
    let shift = false;
    let meta = false;
    for (const token of tokens) {
      const lower = token.toLowerCase();
      const modifier = MODIFIER_ALIASES[lower];
      if (modifier) {
        if (modifier === "Ctrl") ctrl = true;
        if (modifier === "Alt") alt = true;
        if (modifier === "Shift") shift = true;
        if (modifier === "Meta") meta = true;
        continue;
      }
      const normalizedKey = normalizeKeyToken(token);
      if (!normalizedKey) return "";
      if (keyToken) return "";
      keyToken = normalizedKey;
    }
    if (!keyToken) return "";
    const output = [];
    if (ctrl) output.push("Ctrl");
    if (alt) output.push("Alt");
    if (shift) output.push("Shift");
    if (meta) output.push("Meta");
    output.push(keyToken);
    return output.join("+");
  }
  function eventKeyToToken(event) {
    if (event.code === "Backquote" || event.key === "`") return "Backquote";
    if (event.code === "Space" || event.key === " ") return "Space";
    const key = event.key;
    if (!key) return null;
    if (EDITABLE_MODIFIER_KEYS.has(key)) return null;
    const lower = key.toLowerCase();
    if (lower in CANONICAL_SPECIAL_KEYS) {
      return CANONICAL_SPECIAL_KEYS[lower];
    }
    if (key.length === 1) {
      if (/^[a-z]$/i.test(key)) return key.toUpperCase();
      return key;
    }
    return normalizeKeyToken(key);
  }
  function keyboardEventToShortcutString(event) {
    const keyToken = eventKeyToToken(event);
    if (!keyToken) return "";
    const parts = [];
    if (event.ctrlKey) parts.push("Ctrl");
    if (event.altKey) parts.push("Alt");
    if (event.shiftKey) parts.push("Shift");
    if (event.metaKey) parts.push("Meta");
    parts.push(keyToken);
    return parts.join("+");
  }
  function doesKeyboardEventMatchShortcut(event, shortcut) {
    const normalized = normalizeShortcutString(shortcut);
    if (!normalized) return false;
    const eventShortcut = keyboardEventToShortcutString(event);
    if (!eventShortcut) return false;
    return normalized === eventShortcut;
  }

  // src/lib/common/contracts/settings.ts
  var DEFAULT_SETTINGS = {
    urlCopy: {
      showToast: true,
      toastDismissMs: 1800
    },
    autoCopy: {
      enabled: false,
      plainTextMode: true,
      appendMode: false,
      sourceTagMode: false,
      siteRuleMode: "blacklist",
      siteRules: [],
      appendSeparator: "\n",
      showSelectionCountBadge: true
    },
    jsonTooling: {
      prettyPrintEnabled: false,
      tableFromArrayEnabled: false,
      decorateJsonBlocks: false,
      rootPathPrefix: "response.data"
    },
    shortcuts: {
      switchToAutoCopy: "Alt+T",
      jsonToolingPrettyPrint: "Alt+D",
      jsonToolingPathCopy: "Alt+Shift+D",
      jsonToolingMarkdownTable: "Alt+Shift+T",
      copyPageUrl: "Alt+C",
      copyCleanCodeBlock: "Alt+Shift+C",
      copyAsFetch: "Alt+F",
      copyAsCurl: "Alt+Shift+F"
    }
  };
  function cloneSettings(settings) {
    return JSON.parse(JSON.stringify(settings));
  }
  function normalizeJsonToolingSettings(settings) {
    const mode = settings.prettyPrintEnabled ? "mode1" : settings.decorateJsonBlocks ? "mode2" : settings.tableFromArrayEnabled ? "mode3" : "off";
    const rootPathPrefix = typeof settings.rootPathPrefix === "string" && settings.rootPathPrefix.trim() ? settings.rootPathPrefix : DEFAULT_SETTINGS.jsonTooling.rootPathPrefix;
    return {
      prettyPrintEnabled: mode === "mode1",
      decorateJsonBlocks: mode === "mode2",
      tableFromArrayEnabled: mode === "mode3",
      rootPathPrefix
    };
  }
  function mergeSettings(stored) {
    const merged = cloneSettings(DEFAULT_SETTINGS);
    if (!stored || typeof stored !== "object") {
      return merged;
    }
    if (stored.urlCopy) {
      merged.urlCopy = {
        ...merged.urlCopy,
        ...stored.urlCopy
      };
    }
    if (stored.autoCopy) {
      const next = {
        ...merged.autoCopy,
        ...stored.autoCopy
      };
      next.siteRules = Array.isArray(next.siteRules) ? next.siteRules.filter((value) => typeof value === "string") : [];
      merged.autoCopy = next;
    }
    if (stored.jsonTooling) {
      merged.jsonTooling = normalizeJsonToolingSettings({
        ...merged.jsonTooling,
        ...stored.jsonTooling
      });
    }
    if (stored.shortcuts && typeof stored.shortcuts === "object") {
      const incoming = {
        ...merged.shortcuts,
        ...stored.shortcuts
      };
      const keys = Object.keys(merged.shortcuts);
      const normalizedShortcuts = { ...merged.shortcuts };
      for (const key of keys) {
        const raw = incoming[key];
        if (typeof raw !== "string") {
          normalizedShortcuts[key] = merged.shortcuts[key];
          continue;
        }
        const trimmed = raw.trim();
        if (!trimmed) {
          normalizedShortcuts[key] = "";
          continue;
        }
        const normalized = normalizeShortcutString(trimmed);
        normalizedShortcuts[key] = normalized || merged.shortcuts[key];
      }
      merged.shortcuts = normalizedShortcuts;
    }
    return merged;
  }

  // src/lib/common/utils/clipboard.ts
  var fallbackClipboardBuffer = "";
  async function readClipboardText() {
    try {
      const text = await navigator.clipboard.readText();
      fallbackClipboardBuffer = text;
      return text;
    } catch {
      return fallbackClipboardBuffer;
    }
  }
  function fallbackWriteText(text) {
    const activeElement = document.activeElement;
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "true");
    textarea.style.position = "fixed";
    textarea.style.top = "-9999px";
    textarea.style.left = "-9999px";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    const selection = document.getSelection();
    const selectedRange = selection && selection.rangeCount > 0 ? selection.getRangeAt(0).cloneRange() : null;
    textarea.select();
    textarea.setSelectionRange(0, textarea.value.length);
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {
      ok = false;
    }
    document.body.removeChild(textarea);
    if (selectedRange && selection) {
      selection.removeAllRanges();
      selection.addRange(selectedRange);
    }
    if (activeElement) {
      activeElement.focus({ preventScroll: true });
    }
    return ok;
  }
  async function writeClipboardText(text) {
    try {
      await navigator.clipboard.writeText(text);
      fallbackClipboardBuffer = text;
      return true;
    } catch {
      const ok = fallbackWriteText(text);
      if (ok) fallbackClipboardBuffer = text;
      return ok;
    }
  }
  async function appendClipboardText(fragment, separator) {
    const existing = await readClipboardText();
    const next = existing ? `${existing}${separator}${fragment}` : fragment;
    await writeClipboardText(next);
    return next;
  }

  // src/lib/common/utils/helpers.ts
  var HTML_ESCAPE = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var JSON_CODE_FENCE_RE = /^```(?:json)?\n([\s\S]*?)\n```$/i;
  function escapeHtml(text) {
    return text.replace(/[&<>"']/g, (character) => HTML_ESCAPE[character]);
  }
  function normalizeWhitespace(text) {
    return text.replace(/\r\n?/g, "\n").replace(/[\t\f\v]+/g, " ").replace(/[ ]{2,}/g, " ").trim();
  }
  function doesSiteMatchRule(url, rule) {
    const trimmedRule = rule.trim();
    if (!trimmedRule) return false;
    let hostname = "";
    try {
      hostname = new URL(url).hostname.toLowerCase();
    } catch {
      return false;
    }
    const normalizedRule = trimmedRule.toLowerCase();
    if (normalizedRule.includes("*")) {
      const escapedRule = normalizedRule.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
      const ruleRegex = new RegExp(`^${escapedRule}$`);
      return ruleRegex.test(hostname);
    }
    return hostname === normalizedRule || hostname.endsWith(`.${normalizedRule}`);
  }
  function isSiteEnabled(url, autoCopySettings) {
    const rules = autoCopySettings.siteRules || [];
    if (rules.length === 0) return true;
    const hasMatch = rules.some((rule) => doesSiteMatchRule(url, rule));
    if (autoCopySettings.siteRuleMode === "whitelist") {
      return hasMatch;
    }
    return !hasMatch;
  }
  function getSelectedText() {
    const selection = window.getSelection();
    if (!selection) return "";
    return selection.toString();
  }
  function parsePotentialJson(input) {
    const normalized = input.trim();
    if (!normalized) return null;
    const codeFenceMatch = normalized.match(JSON_CODE_FENCE_RE);
    const jsonSource = codeFenceMatch ? codeFenceMatch[1] : normalized;
    try {
      return JSON.parse(jsonSource);
    } catch {
      return null;
    }
  }
  function prettyPrintJson(value) {
    return JSON.stringify(value, null, 2);
  }
  function isArrayOfObjects(value) {
    if (!Array.isArray(value)) return false;
    if (value.length === 0) return false;
    return value.every((entry) => !!entry && typeof entry === "object" && !Array.isArray(entry));
  }
  function stringifyTableCell(value) {
    if (value == null) return "";
    if (typeof value === "string") return value.replace(/\|/g, "\\|").replace(/\n/g, " ");
    if (typeof value === "number" || typeof value === "boolean") return String(value);
    return JSON.stringify(value).replace(/\|/g, "\\|");
  }
  function jsonArrayToMarkdownTable(rows) {
    const columns = Array.from(
      rows.reduce((set, row) => {
        for (const key of Object.keys(row)) set.add(key);
        return set;
      }, /* @__PURE__ */ new Set())
    );
    if (columns.length === 0) return "| value |\n|---|\n| |";
    const header = `| ${columns.join(" | ")} |`;
    const separator = `| ${columns.map(() => "---").join(" | ")} |`;
    const lines = rows.map((row) => {
      const cells = columns.map((column) => stringifyTableCell(row[column]));
      return `| ${cells.join(" | ")} |`;
    });
    return [header, separator, ...lines].join("\n");
  }
  function shorten(text, max = 64) {
    if (text.length <= max) return text;
    return `${text.slice(0, max - 1)}\u2026`;
  }

  // src/lib/common/utils/httpTransforms.ts
  var CODE_FENCE_RE = /^```(?:[\w+-]+)?\n([\s\S]*?)\n```$/i;
  var HTTP_METHOD_RE = /^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)$/i;
  function unwrapCodeFence(input) {
    const trimmed = input.trim();
    const match = trimmed.match(CODE_FENCE_RE);
    return match ? match[1].trim() : trimmed;
  }
  function normalizeMethod(method) {
    const value = (method || "").trim().toUpperCase();
    if (!value) return "GET";
    if (!HTTP_METHOD_RE.test(value)) return "GET";
    return value;
  }
  function isLikelyHttpUrl(text) {
    try {
      const parsed = new URL(text);
      return parsed.protocol === "http:" || parsed.protocol === "https:";
    } catch {
      return false;
    }
  }
  function tryParseJson(text) {
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  }
  function parseJsStringLiteral(input) {
    const value = input.trim();
    if (value.length < 2) return null;
    const quote = value[0];
    if (quote !== "'" && quote !== '"' && quote !== "`") return null;
    if (value[value.length - 1] !== quote) return null;
    if (quote === "`" && value.includes("${")) return null;
    let result = "";
    for (let i = 1; i < value.length - 1; i += 1) {
      const char = value[i];
      if (char !== "\\") {
        result += char;
        continue;
      }
      i += 1;
      if (i >= value.length - 1) break;
      const next = value[i];
      if (next === "n") result += "\n";
      else if (next === "r") result += "\r";
      else if (next === "t") result += "	";
      else if (next === "b") result += "\b";
      else if (next === "f") result += "\f";
      else if (next === "v") result += "\v";
      else if (next === "0") result += "\0";
      else if (next === "x" && i + 2 < value.length - 1) {
        const hex = value.slice(i + 1, i + 3);
        if (/^[0-9a-fA-F]{2}$/.test(hex)) {
          result += String.fromCharCode(Number.parseInt(hex, 16));
          i += 2;
        } else {
          result += next;
        }
      } else if (next === "u" && i + 4 < value.length - 1) {
        const hex = value.slice(i + 1, i + 5);
        if (/^[0-9a-fA-F]{4}$/.test(hex)) {
          result += String.fromCharCode(Number.parseInt(hex, 16));
          i += 4;
        } else {
          result += next;
        }
      } else {
        result += next;
      }
    }
    return result;
  }
  function findMatchingBracket(text, startIndex, openChar, closeChar) {
    let depth = 0;
    let quote = null;
    let escaped = false;
    for (let i = startIndex; i < text.length; i += 1) {
      const char = text[i];
      if (quote) {
        if (escaped) {
          escaped = false;
          continue;
        }
        if (char === "\\") {
          escaped = true;
          continue;
        }
        if (char === quote) {
          quote = null;
        }
        continue;
      }
      if (char === "'" || char === '"' || char === "`") {
        quote = char;
        continue;
      }
      if (char === openChar) {
        depth += 1;
        continue;
      }
      if (char === closeChar) {
        depth -= 1;
        if (depth === 0) return i;
      }
    }
    return -1;
  }
  function splitTopLevel(input, separator) {
    const parts = [];
    let start = 0;
    let quote = null;
    let escaped = false;
    let braceDepth = 0;
    let bracketDepth = 0;
    let parenDepth = 0;
    for (let i = 0; i < input.length; i += 1) {
      const char = input[i];
      if (quote) {
        if (escaped) {
          escaped = false;
          continue;
        }
        if (char === "\\") {
          escaped = true;
          continue;
        }
        if (char === quote) {
          quote = null;
        }
        continue;
      }
      if (char === "'" || char === '"' || char === "`") {
        quote = char;
        continue;
      }
      if (char === "{") braceDepth += 1;
      else if (char === "}") braceDepth = Math.max(0, braceDepth - 1);
      else if (char === "[") bracketDepth += 1;
      else if (char === "]") bracketDepth = Math.max(0, bracketDepth - 1);
      else if (char === "(") parenDepth += 1;
      else if (char === ")") parenDepth = Math.max(0, parenDepth - 1);
      if (char === separator && braceDepth === 0 && bracketDepth === 0 && parenDepth === 0) {
        parts.push(input.slice(start, i).trim());
        start = i + 1;
      }
    }
    parts.push(input.slice(start).trim());
    return parts.filter((part) => part.length > 0);
  }
  function findTopLevelColon(input) {
    let quote = null;
    let escaped = false;
    let braceDepth = 0;
    let bracketDepth = 0;
    let parenDepth = 0;
    for (let i = 0; i < input.length; i += 1) {
      const char = input[i];
      if (quote) {
        if (escaped) {
          escaped = false;
          continue;
        }
        if (char === "\\") {
          escaped = true;
          continue;
        }
        if (char === quote) {
          quote = null;
        }
        continue;
      }
      if (char === "'" || char === '"' || char === "`") {
        quote = char;
        continue;
      }
      if (char === "{") braceDepth += 1;
      else if (char === "}") braceDepth = Math.max(0, braceDepth - 1);
      else if (char === "[") bracketDepth += 1;
      else if (char === "]") bracketDepth = Math.max(0, bracketDepth - 1);
      else if (char === "(") parenDepth += 1;
      else if (char === ")") parenDepth = Math.max(0, parenDepth - 1);
      if (char === ":" && braceDepth === 0 && bracketDepth === 0 && parenDepth === 0) {
        return i;
      }
    }
    return -1;
  }
  function normalizeObjectKey(keySource) {
    const raw = keySource.trim();
    if (!raw) return null;
    const fromLiteral = parseJsStringLiteral(raw);
    if (fromLiteral != null) return fromLiteral;
    const match = raw.match(/^[$A-Z_a-z][$\w]*$/);
    if (match) return match[0];
    return null;
  }
  function parseObjectLiteralTopLevel(source) {
    const output = /* @__PURE__ */ new Map();
    const value = source.trim();
    if (!value.startsWith("{") || !value.endsWith("}")) return output;
    const body = value.slice(1, -1).trim();
    if (!body) return output;
    const entries = splitTopLevel(body, ",");
    for (const entry of entries) {
      const colonIndex = findTopLevelColon(entry);
      if (colonIndex < 0) continue;
      const keySource = entry.slice(0, colonIndex).trim();
      const valueSource = entry.slice(colonIndex + 1).trim();
      const key = normalizeObjectKey(keySource);
      if (!key) continue;
      output.set(key, valueSource);
    }
    return output;
  }
  function parseHeaderValue(raw) {
    const separator = raw.indexOf(":");
    if (separator <= 0) return null;
    const name = raw.slice(0, separator).trim();
    const value = raw.slice(separator + 1).trim();
    if (!name) return null;
    return { name, value };
  }
  function parseHeadersFromObject(rawObject) {
    const map = parseObjectLiteralTopLevel(rawObject);
    if (map.size === 0) {
      const parsedJson = tryParseJson(rawObject);
      if (!parsedJson || typeof parsedJson !== "object" || Array.isArray(parsedJson)) {
        return [];
      }
      return Object.entries(parsedJson).map(([name, value]) => ({
        name,
        value: String(value)
      }));
    }
    const headers = [];
    for (const [name, valueSource] of map.entries()) {
      const fromLiteral = parseJsStringLiteral(valueSource);
      headers.push({
        name,
        value: fromLiteral == null ? valueSource.trim() : fromLiteral
      });
    }
    return headers;
  }
  function tokenizeShellLike(input) {
    const tokens = [];
    let current = "";
    let quote = null;
    let escaped = false;
    for (let i = 0; i < input.length; i += 1) {
      const char = input[i];
      if (quote) {
        if (quote === "'") {
          if (char === "'") {
            quote = null;
          } else {
            current += char;
          }
          continue;
        }
        if (escaped) {
          current += char;
          escaped = false;
          continue;
        }
        if (char === "\\") {
          escaped = true;
          continue;
        }
        if (char === '"') {
          quote = null;
        } else {
          current += char;
        }
        continue;
      }
      if (escaped) {
        current += char;
        escaped = false;
        continue;
      }
      if (char === "\\") {
        escaped = true;
        continue;
      }
      if (char === "'") {
        quote = "'";
        continue;
      }
      if (char === '"') {
        quote = '"';
        continue;
      }
      if (/\s/.test(char)) {
        if (current) {
          tokens.push(current);
          current = "";
        }
        continue;
      }
      current += char;
    }
    if (current) {
      tokens.push(current);
    }
    return tokens;
  }
  function parseCurlRequest(source) {
    const flat = source.replace(/\r\n?/g, "\n").replace(/\\\n/g, " ").replace(/\n+/g, " ").trim();
    if (!flat) return null;
    const tokens = tokenizeShellLike(flat);
    const curlIndex = tokens.findIndex((token) => token.toLowerCase() === "curl");
    if (curlIndex < 0) return null;
    let method = "";
    let url = "";
    const headers = [];
    const dataParts = [];
    let forceGet = false;
    let i = curlIndex + 1;
    while (i < tokens.length) {
      const token = tokens[i];
      const lower = token.toLowerCase();
      const nextToken = i + 1 < tokens.length ? tokens[i + 1] : null;
      if (token === "-X" || lower === "--request") {
        if (nextToken) {
          method = nextToken;
          i += 2;
        } else {
          i += 1;
        }
        continue;
      }
      if (token.startsWith("-X") && token.length > 2) {
        method = token.slice(2);
        i += 1;
        continue;
      }
      if (lower.startsWith("--request=")) {
        method = token.slice(token.indexOf("=") + 1);
        i += 1;
        continue;
      }
      if (token === "-I" || lower === "--head") {
        method = "HEAD";
        i += 1;
        continue;
      }
      if (token === "-G" || lower === "--get") {
        forceGet = true;
        i += 1;
        continue;
      }
      if (token === "-H" || lower === "--header") {
        if (nextToken) {
          const parsed = parseHeaderValue(nextToken);
          if (parsed) headers.push(parsed);
          i += 2;
        } else {
          i += 1;
        }
        continue;
      }
      if (token.startsWith("-H") && token.length > 2) {
        const parsed = parseHeaderValue(token.slice(2));
        if (parsed) headers.push(parsed);
        i += 1;
        continue;
      }
      if (lower.startsWith("--header=")) {
        const parsed = parseHeaderValue(token.slice(token.indexOf("=") + 1));
        if (parsed) headers.push(parsed);
        i += 1;
        continue;
      }
      if (token === "-d" || lower === "--data" || lower === "--data-raw" || lower === "--data-binary" || lower === "--data-urlencode") {
        if (nextToken) {
          dataParts.push(nextToken);
          i += 2;
        } else {
          i += 1;
        }
        continue;
      }
      if (token.startsWith("-d") && token.length > 2) {
        dataParts.push(token.slice(2));
        i += 1;
        continue;
      }
      if (lower.startsWith("--data=") || lower.startsWith("--data-raw=") || lower.startsWith("--data-binary=") || lower.startsWith("--data-urlencode=")) {
        dataParts.push(token.slice(token.indexOf("=") + 1));
        i += 1;
        continue;
      }
      if (lower === "--url") {
        if (nextToken) {
          url = nextToken;
          i += 2;
        } else {
          i += 1;
        }
        continue;
      }
      if (lower.startsWith("--url=")) {
        url = token.slice(token.indexOf("=") + 1);
        i += 1;
        continue;
      }
      if (!token.startsWith("-") && !url && isLikelyHttpUrl(token)) {
        url = token;
        i += 1;
        continue;
      }
      i += 1;
    }
    if (!url) return null;
    let body;
    if (dataParts.length > 0) {
      body = dataParts.join("&");
    }
    if (forceGet) {
      method = "GET";
      if (body) {
        const query = body.startsWith("?") ? body.slice(1) : body;
        const separator = url.includes("?") ? "&" : "?";
        url = `${url}${separator}${query}`;
        body = void 0;
      }
    } else if (!method) {
      method = body ? "POST" : "GET";
    }
    return {
      method: normalizeMethod(method),
      url,
      headers,
      body,
      source: "curl"
    };
  }
  function parseUrlArgument(source) {
    const fromLiteral = parseJsStringLiteral(source);
    if (fromLiteral != null) return fromLiteral;
    const raw = source.trim();
    if (!raw) return null;
    if (isLikelyHttpUrl(raw)) return raw;
    if (raw.startsWith("/")) return raw;
    return null;
  }
  function parseMethodValue(source) {
    const fromLiteral = parseJsStringLiteral(source);
    if (fromLiteral != null) return normalizeMethod(fromLiteral);
    const raw = source.trim().replace(/,$/, "");
    const match = raw.match(/^[A-Za-z]+$/);
    if (!match) return null;
    return normalizeMethod(match[0]);
  }
  function parseBodyFromFetchValue(source) {
    const raw = source.trim();
    if (!raw) return void 0;
    const fromLiteral = parseJsStringLiteral(raw);
    if (fromLiteral != null) return fromLiteral;
    if (/^JSON\.stringify\s*\(/i.test(raw)) {
      const open = raw.indexOf("(");
      const close = open >= 0 ? findMatchingBracket(raw, open, "(", ")") : -1;
      if (open >= 0 && close > open) {
        const inner = raw.slice(open + 1, close).trim();
        const args = splitTopLevel(inner, ",");
        const first = (args[0] || "").trim();
        if (!first) return void 0;
        const firstLiteral = parseJsStringLiteral(first);
        if (firstLiteral != null) return firstLiteral;
        const parsed2 = tryParseJson(first);
        if (parsed2 != null) return JSON.stringify(parsed2);
        return first;
      }
    }
    const parsed = tryParseJson(raw);
    if (parsed != null) return JSON.stringify(parsed);
    return raw;
  }
  function parseFetchRequest(source) {
    const fetchMatch = source.match(/\bfetch\s*\(/);
    if (!fetchMatch || fetchMatch.index == null) return null;
    const openParen = source.indexOf("(", fetchMatch.index);
    if (openParen < 0) return null;
    const closeParen = findMatchingBracket(source, openParen, "(", ")");
    if (closeParen < 0) return null;
    const argsSource = source.slice(openParen + 1, closeParen).trim();
    if (!argsSource) return null;
    const args = splitTopLevel(argsSource, ",");
    if (args.length === 0) return null;
    const url = parseUrlArgument(args[0]);
    if (!url) return null;
    let method = "GET";
    let headers = [];
    let body;
    if (args.length >= 2) {
      const options = parseObjectLiteralTopLevel(args[1]);
      const methodValue = options.get("method");
      const headersValue = options.get("headers");
      const bodyValue = options.get("body");
      if (methodValue) {
        const parsedMethod = parseMethodValue(methodValue);
        if (parsedMethod) method = parsedMethod;
      }
      if (headersValue) {
        headers = parseHeadersFromObject(headersValue);
      }
      if (bodyValue) {
        body = parseBodyFromFetchValue(bodyValue);
        if (!methodValue && body) {
          method = "POST";
        }
      }
    }
    return {
      method: normalizeMethod(method),
      url,
      headers,
      body,
      source: "fetch"
    };
  }
  function parseRawUrlRequest(source) {
    const trimmed = source.trim();
    if (!trimmed) return null;
    const methodUrlMatch = trimmed.match(/^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(\S+)$/i);
    if (methodUrlMatch && isLikelyHttpUrl(methodUrlMatch[2])) {
      return {
        method: normalizeMethod(methodUrlMatch[1]),
        url: methodUrlMatch[2],
        headers: [],
        source: "url"
      };
    }
    if (isLikelyHttpUrl(trimmed)) {
      return {
        method: "GET",
        url: trimmed,
        headers: [],
        source: "url"
      };
    }
    const firstToken = trimmed.split(/\s+/, 1)[0];
    if (isLikelyHttpUrl(firstToken)) {
      return {
        method: "GET",
        url: firstToken,
        headers: [],
        source: "url"
      };
    }
    return null;
  }
  function indentBlock(text, spaces) {
    const pad = " ".repeat(spaces);
    return text.split("\n").map((line) => `${pad}${line}`).join("\n");
  }
  function toShellSingleQuoted(value) {
    return `'${value.replace(/'/g, `'"'"'`)}'`;
  }
  function renderFetchBodyExpression(body) {
    const parsed = tryParseJson(body);
    if (parsed != null) {
      return `JSON.stringify(${JSON.stringify(parsed)})`;
    }
    return JSON.stringify(body);
  }
  function parseHttpRequestShape(input) {
    const source = unwrapCodeFence(input);
    if (!source) return null;
    return parseCurlRequest(source) || parseFetchRequest(source) || parseRawUrlRequest(source);
  }
  function renderHttpRequestAsFetch(request) {
    const method = normalizeMethod(request.method);
    const headers = request.headers;
    const hasBody = typeof request.body === "string" && request.body.length > 0;
    const hasHeaders = headers.length > 0;
    const urlLiteral = JSON.stringify(request.url);
    if (method === "GET" && !hasHeaders && !hasBody) {
      return `await fetch(${urlLiteral});`;
    }
    const optionBlocks = [`method: ${JSON.stringify(method)}`];
    if (hasHeaders) {
      const headerRows = headers.map((header) => `  ${JSON.stringify(header.name)}: ${JSON.stringify(header.value)}`).join(",\n");
      optionBlocks.push(`headers: {
${headerRows}
}`);
    }
    if (hasBody) {
      optionBlocks.push(`body: ${renderFetchBodyExpression(request.body)}`);
    }
    const renderedOptions = optionBlocks.map((block) => indentBlock(block, 2)).join(",\n");
    return `await fetch(${urlLiteral}, {
${renderedOptions}
});`;
  }
  function renderHttpRequestAsCurl(request) {
    const method = normalizeMethod(request.method);
    const includeMethod = method !== "GET" || !!request.body;
    const firstParts = [];
    if (includeMethod) {
      firstParts.push(`-X ${method}`);
    }
    firstParts.push(toShellSingleQuoted(request.url));
    const extraParts = [];
    for (const header of request.headers) {
      extraParts.push(toShellSingleQuoted(`${header.name}: ${header.value}`));
    }
    if (request.body && request.body.length > 0) {
      extraParts.push(`--data-raw ${toShellSingleQuoted(request.body)}`);
    }
    let command = `curl ${firstParts.join(" ")}`;
    for (const part of extraParts) {
      if (part.startsWith("--data-raw")) {
        command += ` \\
  ${part}`;
      } else {
        command += ` \\
  -H ${part}`;
      }
    }
    return command;
  }

  // src/lib/common/utils/toast.ts
  var TOAST_HOST_ID = "yank-toast-host";
  function ensureToastHost() {
    let host = document.getElementById(TOAST_HOST_ID);
    if (host) return host;
    host = document.createElement("div");
    host.id = TOAST_HOST_ID;
    host.style.cssText = [
      "position:fixed",
      "left:50%",
      "transform:translateX(-50%)",
      "top:calc(56px + env(safe-area-inset-top, 0px))",
      "z-index:2147483647",
      "display:flex",
      "flex-direction:column",
      "align-items:center",
      "gap:8px",
      "font-family:'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
      "pointer-events:none"
    ].join(";");
    document.documentElement.appendChild(host);
    return host;
  }
  function showToast(message, options = {}) {
    const host = ensureToastHost();
    const toast = document.createElement("div");
    const kind = options.kind || "success";
    const borderColor = kind === "error" ? "rgba(255,95,87,0.7)" : kind === "warning" ? "rgba(254,188,46,0.7)" : "rgba(50,215,75,0.7)";
    const textColor = kind === "error" ? "#ff7d76" : kind === "warning" ? "#ffd66e" : "#66e07a";
    toast.textContent = message;
    toast.style.cssText = [
      "max-width:480px",
      "padding:8px 12px",
      "border-radius:8px",
      "background:#252525",
      `border:1px solid ${borderColor}`,
      `color:${textColor}`,
      "font-size:12px",
      "line-height:1.35",
      "box-shadow:0 10px 26px rgba(0,0,0,0.45)",
      "opacity:0",
      "transform:translateY(8px)",
      "transition:opacity 0.18s ease, transform 0.18s ease",
      "pointer-events:auto",
      "cursor:pointer"
    ].join(";");
    const dismiss = () => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(8px)";
      window.setTimeout(() => {
        toast.remove();
        if (host.childElementCount === 0) {
          host.remove();
        }
      }, 170);
    };
    toast.addEventListener("click", dismiss);
    host.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
    });
    window.setTimeout(dismiss, options.dismissMs ?? 1800);
  }

  // src/lib/ui/helpMenu/helpMenu.ts
  var HELP_MENU_OVERLAY_ID = "yank-help-menu-overlay";
  function formatShortcut(shortcut) {
    const trimmed = shortcut.trim();
    return trimmed ? trimmed : "Unbound";
  }
  function createKeyBadge(value) {
    const badge = document.createElement("kbd");
    badge.style.cssText = [
      "padding:2px 8px",
      "border-radius:999px",
      "border:1px solid rgba(255,255,255,0.2)",
      "background:rgba(255,255,255,0.06)",
      "color:#ffe4a6",
      "font:12px/1.4 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
      "white-space:nowrap"
    ].join(";");
    badge.textContent = value;
    return badge;
  }
  function createInfoLine(text) {
    const line = document.createElement("div");
    line.style.cssText = "font-size:12px;color:#b8c7db;line-height:1.45";
    line.textContent = text;
    return line;
  }
  function createInfoCard(input) {
    const card = document.createElement("article");
    card.style.cssText = [
      "display:flex",
      "flex-direction:column",
      "gap:8px",
      "padding:12px",
      "border:1px solid rgba(155,198,255,0.24)",
      "border-radius:11px",
      "background:linear-gradient(180deg, rgba(58,76,102,0.26), rgba(255,255,255,0.06))",
      "box-shadow:0 10px 22px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.08)",
      "min-width:0"
    ].join(";");
    const header = document.createElement("div");
    header.style.cssText = [
      "display:flex",
      "align-items:center",
      "justify-content:space-between",
      "gap:8px"
    ].join(";");
    const title = document.createElement("div");
    title.style.cssText = "font-weight:600;color:#d8e8ff";
    title.textContent = input.title;
    header.appendChild(title);
    if (input.key) {
      header.appendChild(createKeyBadge(input.key));
    }
    const body = document.createElement("div");
    body.style.cssText = "display:flex;flex-direction:column;gap:3px";
    for (const line of input.lines) {
      body.appendChild(createInfoLine(line));
    }
    card.append(header, body);
    return card;
  }
  function createSection(title, cards) {
    const section = document.createElement("section");
    section.style.cssText = [
      "display:flex",
      "flex-direction:column",
      "gap:10px"
    ].join(";");
    const heading = document.createElement("div");
    heading.style.cssText = "font-weight:600;color:#9bc6ff;letter-spacing:0.02em";
    heading.textContent = title;
    const grid = document.createElement("div");
    grid.style.cssText = [
      "display:grid",
      "grid-template-columns:repeat(auto-fit, minmax(260px, 1fr))",
      "gap:10px"
    ].join(";");
    for (const card of cards) {
      grid.appendChild(card);
    }
    section.append(heading, grid);
    return section;
  }
  function createHelpMenu() {
    let overlay = null;
    let card = null;
    let cardBody = null;
    let resizeListenerAttached = false;
    function applyResponsiveLayout() {
      if (!overlay || !card || !cardBody) return;
      const viewportWidth = Math.min(window.innerWidth, document.documentElement.clientWidth || window.innerWidth);
      const isPhoneWidth = viewportWidth <= 640;
      const isTabletWidth = viewportWidth <= 960;
      overlay.style.paddingTop = isPhoneWidth ? "calc(10px + env(safe-area-inset-top, 0px))" : "calc(76px + env(safe-area-inset-top, 0px))";
      card.style.width = isPhoneWidth ? "calc(100vw - 12px)" : isTabletWidth ? "min(860px, calc(100vw - 20px))" : "min(920px, calc(100vw - 28px))";
      card.style.maxHeight = isPhoneWidth ? "92vh" : "min(82vh, 760px)";
      cardBody.style.padding = isPhoneWidth ? "10px" : "12px";
      cardBody.style.gap = isPhoneWidth ? "10px" : "12px";
    }
    function ensureElements() {
      if (overlay && card && cardBody) return;
      overlay = document.createElement("div");
      overlay.id = HELP_MENU_OVERLAY_ID;
      overlay.style.cssText = [
        "position:fixed",
        "inset:0",
        "z-index:2147483647",
        "display:flex",
        "align-items:flex-start",
        "justify-content:center",
        "padding-top:calc(76px + env(safe-area-inset-top, 0px))",
        "background:rgba(0,0,0,0.28)",
        "backdrop-filter:blur(2px)",
        "pointer-events:auto"
      ].join(";");
      card = document.createElement("div");
      card.tabIndex = 0;
      card.style.cssText = [
        "width:min(920px, calc(100vw - 28px))",
        "max-height:min(82vh, 760px)",
        "overflow:auto",
        "outline:none",
        "border-radius:14px",
        "border:1px solid rgba(255,255,255,0.16)",
        "background:rgba(32,32,32,0.98)",
        "box-shadow:0 28px 54px rgba(0,0,0,0.5)",
        "font:13px/1.4 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
        "color:#d8e8ff"
      ].join(";");
      const header = document.createElement("div");
      header.style.cssText = [
        "padding:10px 14px",
        "border-bottom:1px solid rgba(255,255,255,0.08)",
        "display:flex",
        "align-items:center",
        "justify-content:space-between",
        "gap:10px"
      ].join(";");
      const title = document.createElement("div");
      title.style.cssText = "font-weight:600;color:#9bc6ff";
      title.textContent = "Yank Help Menu";
      const close = document.createElement("button");
      close.type = "button";
      close.textContent = "Close";
      close.style.cssText = [
        "padding:4px 8px",
        "border-radius:6px",
        "border:1px solid rgba(255,255,255,0.2)",
        "background:rgba(255,255,255,0.06)",
        "color:#d8e8ff",
        "cursor:pointer",
        "font:12px/1.2 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace"
      ].join(";");
      close.addEventListener("click", () => {
        hide();
      });
      header.append(title, close);
      cardBody = document.createElement("div");
      cardBody.style.cssText = [
        "padding:12px",
        "display:flex",
        "flex-direction:column",
        "gap:12px"
      ].join(";");
      const footer = document.createElement("div");
      footer.style.cssText = [
        "padding:10px 14px 12px",
        "border-top:1px solid rgba(255,255,255,0.08)",
        "font-size:12px",
        "color:#98a6bb",
        "text-align:center"
      ].join(";");
      footer.textContent = "Alt+M: Toggle Help Menu | Esc: Close";
      card.append(header, cardBody, footer);
      overlay.appendChild(card);
      overlay.addEventListener("click", (event) => {
        if (event.target === overlay) {
          hide();
        }
      });
      overlay.addEventListener("keydown", (event) => {
        if (!card) return;
        const lower = event.key.toLowerCase();
        if (event.key === "ArrowDown" || lower === "j") {
          event.preventDefault();
          event.stopPropagation();
          card.scrollBy({ top: 48 });
          return;
        }
        if (event.key === "ArrowUp" || lower === "k") {
          event.preventDefault();
          event.stopPropagation();
          card.scrollBy({ top: -48 });
        }
      }, true);
      overlay.addEventListener("wheel", (event) => {
        if (!card) return;
        event.preventDefault();
        event.stopPropagation();
        card.scrollBy({ top: event.deltaY });
      }, { passive: false, capture: true });
      if (!resizeListenerAttached) {
        window.addEventListener("resize", applyResponsiveLayout);
        resizeListenerAttached = true;
      }
      applyResponsiveLayout();
    }
    function render(data) {
      if (!cardBody) return;
      cardBody.textContent = "";
      const quickStart = createSection("Quick Start", [
        createInfoCard({
          title: "Help Menu",
          key: "Alt+M",
          lines: [
            "Toggle this panel on/off.",
            "Press Esc to close."
          ]
        }),
        createInfoCard({
          title: "Auto-Copy Status",
          key: formatShortcut(data.shortcuts.switchToAutoCopy),
          lines: [
            `Current: ${data.autoCopyEnabled ? "On" : "Off"}.`,
            "Toggle to copy selected text automatically."
          ]
        }),
        createInfoCard({
          title: "JSON Tools Status",
          lines: [
            "No dedicated Off key: press active JSON mode key again to turn Off."
          ]
        })
      ]);
      const actions = createSection("Actions", [
        createInfoCard({
          title: "Copy Current Page URL",
          key: formatShortcut(data.shortcuts.copyPageUrl),
          lines: [
            "Do: Press this key on any page.",
            "Input: current tab URL.",
            "Result: raw URL copied."
          ]
        }),
        createInfoCard({
          title: "Copy Clean Code Block",
          key: formatShortcut(data.shortcuts.copyCleanCodeBlock),
          lines: [
            "Do: Select code (or place cursor/hover near code) then press key.",
            "Input: selection -> caret/focus code -> hovered/nearest code block.",
            "Result: cleaned code copied."
          ]
        }),
        createInfoCard({
          title: "Copy as Fetch",
          key: formatShortcut(data.shortcuts.copyAsFetch),
          lines: [
            "Do: Select request text and press key.",
            "Input: selection -> code source -> clipboard fallback.",
            "Result: fetch(...) code copied."
          ]
        }),
        createInfoCard({
          title: "Copy as cURL",
          key: formatShortcut(data.shortcuts.copyAsCurl),
          lines: [
            "Do: Select request text and press key.",
            "Input: selection -> code source -> clipboard fallback.",
            "Result: curl command copied."
          ]
        })
      ]);
      const jsonModes = createSection("JSON Tools Modes", [
        createInfoCard({
          title: "Off",
          lines: [
            "No dedicated Off keybind.",
            "Press the currently active JSON mode key again.",
            "Copy behavior stays unchanged."
          ]
        }),
        createInfoCard({
          title: "Pretty Print",
          key: formatShortcut(data.shortcuts.jsonToolingPrettyPrint),
          lines: [
            "Press key to enable Pretty Print.",
            "Press same key again to toggle Off."
          ]
        }),
        createInfoCard({
          title: "Path Copy",
          key: formatShortcut(data.shortcuts.jsonToolingPathCopy),
          lines: [
            "Press key to enable Path Copy.",
            "Click JSON keys in decorated blocks to copy full paths."
          ]
        }),
        createInfoCard({
          title: "Markdown Table",
          key: formatShortcut(data.shortcuts.jsonToolingMarkdownTable),
          lines: [
            "Press key to enable Markdown Table.",
            "Press same key again to toggle Off."
          ]
        })
      ]);
      cardBody.append(quickStart, actions, jsonModes);
    }
    function show(data) {
      ensureElements();
      render(data);
      if (!overlay || document.contains(overlay)) return;
      document.documentElement.appendChild(overlay);
      applyResponsiveLayout();
      card?.focus();
    }
    function hide() {
      overlay?.remove();
    }
    function toggle(data) {
      if (overlay && document.contains(overlay)) {
        hide();
        return;
      }
      show(data);
    }
    function update(data) {
      if (!overlay || !document.contains(overlay)) return;
      render(data);
    }
    function isVisible() {
      return Boolean(overlay && document.contains(overlay));
    }
    function destroy() {
      hide();
      if (resizeListenerAttached) {
        window.removeEventListener("resize", applyResponsiveLayout);
        resizeListenerAttached = false;
      }
      overlay = null;
      card = null;
      cardBody = null;
    }
    return {
      toggle,
      hide,
      update,
      isVisible,
      destroy
    };
  }

  // src/lib/ui/modePill/modePill.ts
  var MODE_PILL_ID = "yank-mode-pill";
  function createModePill(initialText) {
    const existing = document.getElementById(MODE_PILL_ID);
    if (existing) existing.remove();
    const pill = document.createElement("div");
    pill.id = MODE_PILL_ID;
    pill.style.cssText = [
      "position:fixed",
      "left:50%",
      "transform:translateX(-50%)",
      "top:calc(12px + env(safe-area-inset-top, 0px))",
      "z-index:2147483647",
      "display:none",
      "align-items:center",
      "gap:10px",
      "padding:8px 12px",
      "border-radius:999px",
      "border:1px solid rgba(255,255,255,0.14)",
      "background:rgba(37,37,37,0.95)",
      "color:#a8d2ff",
      "font:12px/1.3 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
      "box-shadow:0 12px 28px rgba(0,0,0,0.45)",
      "backdrop-filter:blur(6px)",
      "pointer-events:auto"
    ].join(";");
    const text = document.createElement("span");
    text.style.cssText = "white-space:nowrap";
    const dismiss = document.createElement("button");
    dismiss.type = "button";
    dismiss.textContent = "x";
    dismiss.title = "Dismiss";
    dismiss.style.cssText = [
      "border:none",
      "background:rgba(255,255,255,0.08)",
      "color:#c6c6c6",
      "width:18px",
      "height:18px",
      "border-radius:50%",
      "cursor:pointer",
      "display:flex",
      "align-items:center",
      "justify-content:center",
      "font:12px/1 monospace"
    ].join(";");
    dismiss.addEventListener("click", () => {
      pill.remove();
    });
    pill.append(text, dismiss);
    document.documentElement.appendChild(pill);
    function setText(value) {
      text.textContent = value;
    }
    function setVisible(visible) {
      pill.style.display = visible ? "flex" : "none";
    }
    function flash() {
      pill.animate(
        [
          { transform: "translateX(-50%) translateY(6px)", opacity: 0.6 },
          { transform: "translateX(-50%) translateY(0)", opacity: 1 }
        ],
        { duration: 180, easing: "ease-out" }
      );
    }
    setText(initialText);
    return {
      setText,
      setVisible,
      flash,
      destroy() {
        pill.remove();
      }
    };
  }

  // src/lib/appInit/appInit.ts
  var CODE_BLOCK_SELECTOR = [
    "pre",
    "code",
    ".monaco-editor",
    ".CodeMirror",
    ".cm-editor",
    ".highlight",
    ".hljs",
    "[class*='language-']"
  ].join(",");
  var CODE_COPY_NEAR_THRESHOLD_PX = 140;
  var HELP_MENU_SHORTCUT = "Alt+M";
  var INSTANCE_LOCK_ATTR = "data-yank-instance-active";
  var SHORTCUT_DEDUP_LOCK_ATTR = "data-yank-shortcut-lock";
  var SHORTCUT_DEDUP_MS = 220;
  function isEditableElement(node) {
    if (!(node instanceof HTMLElement)) return false;
    if (node.isContentEditable) return true;
    if (node.tagName === "TEXTAREA") return true;
    if (node.tagName !== "INPUT") return false;
    const input = node;
    const editableTypes = /* @__PURE__ */ new Set([
      "text",
      "search",
      "url",
      "tel",
      "email",
      "password",
      "number"
    ]);
    return editableTypes.has(input.type);
  }
  function getSelectionRangeRect() {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return null;
    const range = selection.getRangeAt(0);
    if (range.collapsed) return null;
    const rect = range.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return null;
    return rect;
  }
  function renderSelectionCountBadge(charCount) {
    const rect = getSelectionRangeRect();
    if (!rect) return;
    const badge = document.createElement("div");
    badge.textContent = `${charCount} chars`;
    badge.style.cssText = [
      "position:fixed",
      `left:${Math.max(8, rect.left)}px`,
      `top:${Math.max(8, rect.top - 28)}px`,
      "z-index:2147483647",
      "padding:2px 6px",
      "border-radius:6px",
      "border:1px solid rgba(10,132,255,0.35)",
      "background:rgba(20,30,45,0.96)",
      "color:#9ecbff",
      "font:11px/1.2 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
      "box-shadow:0 8px 18px rgba(0,0,0,0.34)",
      "pointer-events:none",
      "opacity:0",
      "transform:translateY(6px)",
      "transition:opacity 0.14s ease, transform 0.14s ease"
    ].join(";");
    document.documentElement.appendChild(badge);
    requestAnimationFrame(() => {
      badge.style.opacity = "1";
      badge.style.transform = "translateY(0)";
    });
    window.setTimeout(() => {
      badge.style.opacity = "0";
      badge.style.transform = "translateY(6px)";
      window.setTimeout(() => badge.remove(), 140);
    }, 650);
  }
  function jsonPrimitiveToHtml(value) {
    if (typeof value === "string") {
      return `<span class="yank-json-string">"${escapeHtml(value)}"</span>`;
    }
    if (typeof value === "number") {
      return `<span class="yank-json-number">${String(value)}</span>`;
    }
    if (typeof value === "boolean") {
      return `<span class="yank-json-boolean">${String(value)}</span>`;
    }
    if (value === null) {
      return `<span class="yank-json-null">null</span>`;
    }
    return `<span class="yank-json-unknown">${escapeHtml(String(value))}</span>`;
  }
  function renderJsonWithPaths(value, pathPrefix, depth = 0) {
    const indent = "  ".repeat(depth);
    if (Array.isArray(value)) {
      if (value.length === 0) return "[]";
      const lines = ["["];
      value.forEach((entry, index) => {
        const path = `${pathPrefix}[${index}]`;
        const rendered = renderJsonWithPaths(entry, path, depth + 1);
        const comma = index === value.length - 1 ? "" : ",";
        lines.push(`${indent}  ${rendered}${comma}`);
      });
      lines.push(`${indent}]`);
      return lines.join("\n");
    }
    if (value && typeof value === "object") {
      const entries = Object.entries(value);
      if (entries.length === 0) return "{}";
      const lines = ["{"];
      entries.forEach(([key, entry], index) => {
        const path = pathPrefix ? `${pathPrefix}.${key}` : key;
        const rendered = renderJsonWithPaths(entry, path, depth + 1);
        const comma = index === entries.length - 1 ? "" : ",";
        const safePath = escapeHtml(path);
        const safeKey = escapeHtml(key);
        lines.push(
          `${indent}  <span class="yank-json-key" data-yank-path="${safePath}" title="${safePath}">"${safeKey}"</span>: ${rendered}${comma}`
        );
      });
      lines.push(`${indent}}`);
      return lines.join("\n");
    }
    return jsonPrimitiveToHtml(value);
  }
  function ensureJsonDecorationStyle() {
    if (document.getElementById("yank-json-decoration-style")) return;
    const style = document.createElement("style");
    style.id = "yank-json-decoration-style";
    style.textContent = `
    .yank-json-host {
      white-space: pre !important;
      overflow: auto !important;
      font-family: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace !important;
      line-height: 1.5 !important;
      tab-size: 2 !important;
    }
    .yank-json-key {
      color: #9bc6ff !important;
      cursor: pointer !important;
      text-decoration: underline dotted rgba(155, 198, 255, 0.4);
    }
    .yank-json-key:hover {
      color: #d3e7ff !important;
      background: rgba(10, 132, 255, 0.16) !important;
      border-radius: 3px;
    }
    .yank-json-string { color: #f5bc6f !important; }
    .yank-json-number { color: #d6a4ff !important; }
    .yank-json-boolean { color: #ff8c8c !important; }
    .yank-json-null { color: #8bb8d6 !important; }
    .yank-json-unknown { color: #b0b0b0 !important; }
  `;
    document.documentElement.appendChild(style);
  }
  function nodeToElement(node) {
    if (!node) return null;
    if (node instanceof HTMLElement) return node;
    if (node.parentElement) return node.parentElement;
    return null;
  }
  function isLikelyCodeBlockElement(element) {
    const tag = element.tagName;
    if (tag === "PRE") return true;
    if (tag === "CODE") {
      return element.parentElement?.tagName === "PRE" || getComputedStyle(element).display.includes("block");
    }
    const classText = `${element.className || ""}`.toLowerCase();
    return classText.includes("code") || classText.includes("monaco") || classText.includes("codemirror") || classText.includes("hljs") || classText.includes("highlight") || classText.includes("language-");
  }
  function closestCodeContainerFromNode(node) {
    const element = nodeToElement(node);
    if (!element) return null;
    const closest = element.closest(CODE_BLOCK_SELECTOR);
    if (!closest || !isLikelyCodeBlockElement(closest)) return null;
    if (closest.tagName === "CODE" && closest.parentElement?.tagName === "PRE") {
      return closest.parentElement;
    }
    return closest;
  }
  function getElementRects(element) {
    const rects = Array.from(element.getClientRects()).filter((rect) => rect.width > 0 && rect.height > 0);
    if (rects.length > 0) return rects;
    const box = element.getBoundingClientRect();
    if (box.width > 0 && box.height > 0) return [box];
    return [];
  }
  function getRangeRects(range) {
    const rects = Array.from(range.getClientRects()).filter((rect) => rect.width > 0 && rect.height > 0);
    if (rects.length > 0) return rects;
    const box = range.getBoundingClientRect();
    if (box.width > 0 && box.height > 0) return [box];
    return [];
  }
  function elementTextForCopy(element) {
    const textFromInnerText = element.innerText || "";
    if (textFromInnerText.trim().length > 0) return textFromInnerText;
    return element.textContent || "";
  }
  function stripLeadingLineNumbers(lines) {
    const candidates = lines.filter((line) => line.trim().length > 0);
    if (candidates.length < 2) return lines;
    const numberedCount = candidates.filter((line) => /^\s*\d+\s{1,3}\S/.test(line)).length;
    if (numberedCount / candidates.length < 0.6) return lines;
    return lines.map((line) => line.replace(/^(\s*)\d+\s{1,3}(?=\S)/, "$1"));
  }
  function stripPromptPrefixes(lines) {
    const candidates = lines.filter((line) => line.trim().length > 0);
    if (candidates.length === 0) return lines;
    const promptSpecs = [
      { prefix: "$", regex: /^\s*\$\s/ },
      { prefix: ">>>", regex: /^\s*>>>\s/ },
      { prefix: "...", regex: /^\s*\.\.\.\s/ }
    ];
    for (const spec of promptSpecs) {
      const count = candidates.filter((line) => spec.regex.test(line)).length;
      if (count < Math.max(1, Math.ceil(candidates.length * 0.55))) continue;
      return lines.map((line) => line.replace(spec.regex, ""));
    }
    return lines;
  }
  function cleanCopiedCode(rawText) {
    let text = rawText.replace(/\r\n?/g, "\n").replace(/\u00a0/g, " ").replace(/[\u200b-\u200d\ufeff]/g, "");
    let lines = text.split("\n");
    while (lines.length > 0 && lines[0].trim() === "") lines.shift();
    while (lines.length > 0 && lines[lines.length - 1].trim() === "") lines.pop();
    lines = stripLeadingLineNumbers(lines);
    lines = stripPromptPrefixes(lines);
    lines = lines.map((line) => line.replace(/[ \t]+$/g, ""));
    text = lines.join("\n");
    return text.trim().length > 0 ? text : rawText.trim();
  }
  function distancePointToRect(x, y, rect) {
    const dx = x < rect.left ? rect.left - x : x > rect.right ? x - rect.right : 0;
    const dy = y < rect.top ? rect.top - y : y > rect.bottom ? y - rect.bottom : 0;
    return Math.hypot(dx, dy);
  }
  function flashCodeCopyOverlay(rects) {
    const visibleRects = rects.filter((rect) => rect.width > 0 && rect.height > 0).slice(0, 120);
    if (visibleRects.length === 0) return;
    const host = document.createElement("div");
    host.style.cssText = [
      "position:fixed",
      "inset:0",
      "z-index:2147483647",
      "pointer-events:none"
    ].join(";");
    const highlightNodes = [];
    for (const rect of visibleRects) {
      const marker = document.createElement("div");
      marker.style.cssText = [
        "position:fixed",
        `left:${rect.left}px`,
        `top:${rect.top}px`,
        `width:${rect.width}px`,
        `height:${rect.height}px`,
        "background:rgba(254,188,46,0.12)",
        "border:1px solid rgba(254,188,46,0.78)",
        "box-shadow:0 0 0 1px rgba(254,188,46,0.3), 0 0 10px rgba(254,188,46,0.25)",
        "border-radius:6px",
        "opacity:0",
        "transition:opacity 0.18s ease"
      ].join(";");
      host.appendChild(marker);
      highlightNodes.push(marker);
    }
    document.documentElement.appendChild(host);
    requestAnimationFrame(() => {
      for (const marker of highlightNodes) {
        marker.style.opacity = "1";
      }
    });
    window.setTimeout(() => {
      for (const marker of highlightNodes) {
        marker.style.opacity = "0";
      }
      window.setTimeout(() => host.remove(), 230);
    }, 240);
  }
  function shouldSuppressDuplicateShortcut(event) {
    if (event.repeat) return true;
    const shortcut = keyboardEventToShortcutString(event);
    if (!shortcut) return false;
    const host = document.documentElement;
    const raw = host.getAttribute(SHORTCUT_DEDUP_LOCK_ATTR) || "";
    const separatorIndex = raw.lastIndexOf("::");
    if (separatorIndex > 0) {
      const lastShortcut = raw.slice(0, separatorIndex);
      const lastTs = Number.parseInt(raw.slice(separatorIndex + 2), 10);
      if (lastShortcut === shortcut && Number.isFinite(lastTs) && Date.now() - lastTs < SHORTCUT_DEDUP_MS) {
        return true;
      }
    }
    host.setAttribute(SHORTCUT_DEDUP_LOCK_ATTR, `${shortcut}::${Date.now()}`);
    return false;
  }
  function initApp() {
    const root = document.documentElement;
    if (root.hasAttribute(INSTANCE_LOCK_ATTR)) {
      return;
    }
    root.setAttribute(INSTANCE_LOCK_ATTR, "1");
    if (window.__yankCleanup) {
      window.__yankCleanup();
    }
    let settingsState = mergeSettings(void 0);
    let modePill = createModePill("");
    const helpMenu = createHelpMenu();
    let lastAutoCopiedSelection = "";
    let autoCopyTimer = null;
    let jsonDecorationTimer = null;
    let hoveredCodeElement = null;
    let pointerClientX = null;
    let pointerClientY = null;
    let lastJsonToolingWarningMessage = "";
    let lastJsonToolingWarningTs = 0;
    function currentSettings() {
      return settingsState;
    }
    function resolveJsonToolingMode(settings) {
      if (settings.prettyPrintEnabled) return "mode1";
      if (settings.decorateJsonBlocks) return "mode2";
      if (settings.tableFromArrayEnabled) return "mode3";
      return "off";
    }
    function jsonToolingModeLabel(mode) {
      if (mode === "mode1") return "Pretty Print";
      if (mode === "mode2") return "Path Copy";
      if (mode === "mode3") return "Markdown Table";
      return "Off";
    }
    function buildJsonToolingModePatch(current, mode) {
      return {
        ...current,
        prettyPrintEnabled: mode === "mode1",
        decorateJsonBlocks: mode === "mode2",
        tableFromArrayEnabled: mode === "mode3"
      };
    }
    function buildHelpMenuData(settings) {
      return {
        shortcuts: settings.shortcuts,
        autoCopyEnabled: settings.autoCopy.enabled,
        jsonModeLabel: jsonToolingModeLabel(resolveJsonToolingMode(settings.jsonTooling))
      };
    }
    function closeTransientPanels() {
      helpMenu.hide();
    }
    function showJsonToolingWarning(message) {
      const now = Date.now();
      if (lastJsonToolingWarningMessage === message && now - lastJsonToolingWarningTs < 900) return;
      lastJsonToolingWarningMessage = message;
      lastJsonToolingWarningTs = now;
      showToast(message, { kind: "warning", dismissMs: 1700 });
    }
    function isJsonToolingTransformEnabled(settings) {
      return settings.jsonTooling.prettyPrintEnabled || settings.jsonTooling.tableFromArrayEnabled;
    }
    function resolveJsonToolingActiveLabel(settings) {
      if (settings.jsonTooling.prettyPrintEnabled) return "JSON Tools: Pretty Print";
      if (settings.jsonTooling.decorateJsonBlocks) return "JSON Tools: Path Copy";
      if (settings.jsonTooling.tableFromArrayEnabled) return "JSON Tools: Markdown Table";
      return null;
    }
    function hasActivePillState(settings) {
      return settings.autoCopy.enabled || resolveJsonToolingActiveLabel(settings) != null;
    }
    function syncModePill() {
      const settings = currentSettings();
      const labels = [];
      if (settings.autoCopy.enabled) {
        labels.push("Auto-Copy");
      }
      const jsonToolingLabel = resolveJsonToolingActiveLabel(settings);
      if (jsonToolingLabel) {
        labels.push(jsonToolingLabel);
      }
      if (labels.length === 0) {
        modePill.setVisible(false);
        return;
      }
      modePill.setVisible(true);
      modePill.setText(labels.join(" \u2022 "));
    }
    async function refreshState() {
      settingsState = await getSettings();
      syncModePill();
    }
    async function runPageCopy() {
      const settings = currentSettings();
      const copied = await writeClipboardText(location.href);
      if (settings.urlCopy.showToast) {
        showToast(copied ? "Copied current page URL" : "Clipboard write failed", {
          kind: copied ? "success" : "error",
          dismissMs: settings.urlCopy.toastDismissMs
        });
      }
    }
    function buildCandidateFromElement(element) {
      const rawText = elementTextForCopy(element);
      const cleaned = cleanCopiedCode(rawText);
      if (!cleaned.trim()) return null;
      const rects = getElementRects(element);
      if (rects.length === 0) return null;
      return { text: cleaned, rects };
    }
    function detectCodeCopyCandidate() {
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
        const range = selection.getRangeAt(0);
        const startCode = closestCodeContainerFromNode(range.startContainer);
        const endCode = closestCodeContainerFromNode(range.endContainer);
        if (startCode && endCode && startCode === endCode) {
          const cleanedSelection = cleanCopiedCode(range.toString());
          if (cleanedSelection.trim()) {
            const rects = getRangeRects(range);
            if (rects.length > 0) {
              return { text: cleanedSelection, rects };
            }
          }
        }
      }
      const caretCode = selection && selection.rangeCount > 0 ? closestCodeContainerFromNode(selection.anchorNode) : null;
      if (caretCode) {
        const candidate = buildCandidateFromElement(caretCode);
        if (candidate) return candidate;
      }
      const focusedCode = closestCodeContainerFromNode(document.activeElement);
      if (focusedCode) {
        const candidate = buildCandidateFromElement(focusedCode);
        if (candidate) return candidate;
      }
      if (hoveredCodeElement && document.contains(hoveredCodeElement)) {
        const candidate = buildCandidateFromElement(hoveredCodeElement);
        if (candidate) return candidate;
      }
      if (pointerClientX == null || pointerClientY == null) return null;
      const blocks = Array.from(document.querySelectorAll(CODE_BLOCK_SELECTOR)).filter((element) => isLikelyCodeBlockElement(element)).filter((element) => {
        const rect = element.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return false;
        if (rect.bottom < 0 || rect.top > window.innerHeight) return false;
        return elementTextForCopy(element).trim().length >= 8;
      });
      let bestElement = null;
      let bestDistance = Number.POSITIVE_INFINITY;
      for (const block of blocks) {
        const rect = block.getBoundingClientRect();
        const distance = distancePointToRect(pointerClientX, pointerClientY, rect);
        if (distance < bestDistance) {
          bestDistance = distance;
          bestElement = block;
        }
      }
      if (!bestElement || bestDistance > CODE_COPY_NEAR_THRESHOLD_PX) return null;
      return buildCandidateFromElement(bestElement);
    }
    function detectHttpTransformCandidate() {
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
        const range = selection.getRangeAt(0);
        const cleanedSelection = cleanCopiedCode(range.toString());
        if (cleanedSelection.trim()) {
          return {
            text: cleanedSelection,
            rects: getRangeRects(range),
            source: "selection"
          };
        }
      }
      const codeCandidate = detectCodeCopyCandidate();
      if (codeCandidate) {
        return {
          text: codeCandidate.text,
          rects: codeCandidate.rects,
          source: "code-block"
        };
      }
      return null;
    }
    async function runCleanCodeBlockCopy() {
      const candidate = detectCodeCopyCandidate();
      if (!candidate) {
        showToast("No code block found near selection/cursor.", { kind: "warning" });
        return;
      }
      const copied = await writeClipboardText(candidate.text);
      if (copied) {
        flashCodeCopyOverlay(candidate.rects);
      }
      const lineCount = Math.max(1, candidate.text.split("\n").length);
      const plural = lineCount === 1 ? "line" : "lines";
      showToast(copied ? `Copied clean code (${lineCount} ${plural})` : "Clipboard write failed", {
        kind: copied ? "success" : "error"
      });
    }
    async function runHttpTransformCopy(target) {
      const inlineCandidate = detectHttpTransformCandidate();
      let candidate = inlineCandidate;
      if (!candidate) {
        const clipboardSource = cleanCopiedCode(await readClipboardText());
        if (clipboardSource.trim()) {
          candidate = {
            text: clipboardSource,
            rects: [],
            source: "clipboard"
          };
        }
      }
      if (!candidate) {
        showToast("No request text found in selection/code/clipboard.", { kind: "warning" });
        return;
      }
      const requestShape = parseHttpRequestShape(candidate.text);
      if (!requestShape) {
        showToast("Could not parse an HTTP request.", { kind: "warning" });
        return;
      }
      const output = target === "fetch" ? renderHttpRequestAsFetch(requestShape) : renderHttpRequestAsCurl(requestShape);
      const copied = await writeClipboardText(output);
      if (copied && candidate.source !== "clipboard" && candidate.rects.length > 0) {
        flashCodeCopyOverlay(candidate.rects);
      }
      const targetLabel = target === "fetch" ? "Fetch" : "cURL";
      const requestSummary = shorten(`${requestShape.method} ${requestShape.url}`, 78);
      showToast(copied ? `Copied as ${targetLabel} (${requestSummary})` : "Clipboard write failed", {
        kind: copied ? "success" : "error"
      });
    }
    async function runAutoCopyFromSelection() {
      const settings = currentSettings();
      if (!settings.autoCopy.enabled) return;
      if (!isSiteEnabled(location.href, settings.autoCopy)) return;
      const rawSelection = getSelectedText();
      const selected = settings.autoCopy.plainTextMode ? normalizeWhitespace(rawSelection) : rawSelection.replace(/\r\n?/g, "\n").trim();
      if (!selected) return;
      const signature = `${selected}:::${location.href}`;
      if (signature === lastAutoCopiedSelection) return;
      if (settings.autoCopy.showSelectionCountBadge) {
        renderSelectionCountBadge(selected.length);
      }
      const withSourceTag = settings.autoCopy.sourceTagMode ? `${selected}

- ${location.href}` : selected;
      if (settings.autoCopy.appendMode) {
        await appendClipboardText(withSourceTag, settings.autoCopy.appendSeparator);
      } else {
        await writeClipboardText(withSourceTag);
      }
      lastAutoCopiedSelection = signature;
      showToast(`Auto-copied ${withSourceTag.length} chars`, { dismissMs: 1200 });
    }
    function scheduleAutoCopy() {
      if (autoCopyTimer != null) {
        window.clearTimeout(autoCopyTimer);
      }
      autoCopyTimer = window.setTimeout(() => {
        void runAutoCopyFromSelection();
      }, 120);
    }
    function transformJsonForJsonTooling(value) {
      const settings = currentSettings();
      if (settings.jsonTooling.tableFromArrayEnabled) {
        if (isArrayOfObjects(value)) {
          return jsonArrayToMarkdownTable(value);
        }
        return null;
      }
      if (settings.jsonTooling.prettyPrintEnabled) {
        return prettyPrintJson(value);
      }
      return null;
    }
    function maybeTransformCopyEvent(event) {
      const settings = currentSettings();
      if (!isJsonToolingTransformEnabled(settings)) return;
      const selected = getSelectedText().trim();
      if (!selected) {
        if (settings.jsonTooling.prettyPrintEnabled) {
          showJsonToolingWarning("JSON Tools Pretty Print: no selected text to transform.");
        } else if (settings.jsonTooling.tableFromArrayEnabled) {
          showJsonToolingWarning("JSON Tools Markdown Table: no selected text to transform.");
        } else {
          showJsonToolingWarning("JSON Tools: no selected text to transform.");
        }
        return;
      }
      const parsed = parsePotentialJson(selected);
      if (parsed == null) {
        if (settings.jsonTooling.prettyPrintEnabled) {
          showJsonToolingWarning("JSON Tools Pretty Print: copied text is not valid JSON.");
        } else if (settings.jsonTooling.tableFromArrayEnabled) {
          showJsonToolingWarning("JSON Tools Markdown Table: copied text is not valid JSON.");
        } else {
          showJsonToolingWarning("JSON Tools: copied text is not valid JSON.");
        }
        return;
      }
      const transformed = transformJsonForJsonTooling(parsed);
      if (transformed == null) {
        if (settings.jsonTooling.tableFromArrayEnabled) {
          showJsonToolingWarning("JSON Tools Markdown Table requires a JSON array of objects.");
        } else {
          showJsonToolingWarning("JSON Tools Pretty Print could not transform copied JSON.");
        }
        return;
      }
      if (!event.clipboardData) {
        void writeClipboardText(transformed).then((ok) => {
          showToast(ok ? "JSON Tools transformed copied JSON" : "JSON Tools could not write transformed JSON.", {
            kind: ok ? "success" : "error"
          });
        });
        return;
      }
      event.preventDefault();
      event.clipboardData.setData("text/plain", transformed);
      showToast("JSON Tools transformed copied JSON");
    }
    function decorateJsonBlocksForPathCopy() {
      if (!currentSettings().jsonTooling.decorateJsonBlocks) return 0;
      ensureJsonDecorationStyle();
      let decoratedCount = 0;
      const blocks = document.querySelectorAll("pre, code");
      blocks.forEach((block) => {
        if (block.dataset.yankJsonDecorated === "1") return;
        if (block.tagName === "CODE" && block.parentElement?.tagName === "PRE") return;
        const source = block.textContent?.trim() || "";
        if (source.length < 2 || source.length > 4e4) return;
        const parsed = parsePotentialJson(source);
        if (parsed == null) return;
        const rootPath = currentSettings().jsonTooling.rootPathPrefix || "response.data";
        const rendered = renderJsonWithPaths(parsed, rootPath, 0);
        block.dataset.yankJsonDecorated = "1";
        block.classList.add("yank-json-host");
        block.innerHTML = rendered;
        decoratedCount += 1;
      });
      return decoratedCount;
    }
    function scheduleJsonBlockDecoration(notifyWhenNone = false) {
      if (jsonDecorationTimer != null) {
        window.clearTimeout(jsonDecorationTimer);
      }
      jsonDecorationTimer = window.setTimeout(() => {
        if (!currentSettings().jsonTooling.decorateJsonBlocks) return;
        const decoratedCount = decorateJsonBlocksForPathCopy();
        if (notifyWhenNone && decoratedCount === 0) {
          showJsonToolingWarning("JSON Tools Path Copy: no JSON code blocks found on this page.");
        }
      }, 120);
    }
    async function toggleAutoCopyByShortcut() {
      const settings = currentSettings();
      const nextEnabled = !settings.autoCopy.enabled;
      const nextAutoCopy = {
        ...settings.autoCopy,
        enabled: nextEnabled
      };
      await patchSettings({
        autoCopy: nextAutoCopy
      });
      await refreshState();
      syncModePill();
      if (hasActivePillState(currentSettings())) {
        modePill.flash();
      }
      showToast(nextEnabled ? "Auto-Copy enabled" : "Auto-Copy disabled", {
        kind: "success"
      });
    }
    async function switchJsonToolingModeByShortcut(targetMode) {
      const settings = currentSettings();
      const currentMode = resolveJsonToolingMode(settings.jsonTooling);
      const nextMode = currentMode === targetMode ? "off" : targetMode;
      const nextJsonTooling = buildJsonToolingModePatch(settings.jsonTooling, nextMode);
      await patchSettings({
        jsonTooling: nextJsonTooling
      });
      await refreshState();
      syncModePill();
      if (hasActivePillState(currentSettings())) {
        modePill.flash();
      }
      if (nextMode === "mode2") {
        scheduleJsonBlockDecoration(true);
      }
      showToast(
        nextMode === "off" ? "JSON Tools disabled" : `JSON Tools mode: ${jsonToolingModeLabel(nextMode)}`,
        { kind: "success" }
      );
    }
    async function handleRuntimeMessage(message) {
      const runtimeMessage = message;
      if (runtimeMessage.type === "SHOW_TOAST") {
        showToast(runtimeMessage.toast.message, {
          kind: runtimeMessage.toast.kind || "success"
        });
        return { ok: true };
      }
      if (runtimeMessage.type === "RUN_COPY_PAGE_URL") {
        await runPageCopy();
        return { ok: true };
      }
      return void 0;
    }
    async function keydownHandler(event) {
      if (shouldSuppressDuplicateShortcut(event)) {
        return;
      }
      if (event.key === "Escape" && helpMenu.isVisible()) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        helpMenu.hide();
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, HELP_MENU_SHORTCUT)) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        helpMenu.toggle(buildHelpMenuData(currentSettings()));
        return;
      }
      if (helpMenu.isVisible()) {
        return;
      }
      const shortcuts = currentSettings().shortcuts;
      if (doesKeyboardEventMatchShortcut(event, shortcuts.switchToAutoCopy)) {
        event.preventDefault();
        event.stopPropagation();
        await toggleAutoCopyByShortcut();
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, shortcuts.jsonToolingPrettyPrint)) {
        event.preventDefault();
        event.stopPropagation();
        await switchJsonToolingModeByShortcut("mode1");
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, shortcuts.jsonToolingPathCopy)) {
        event.preventDefault();
        event.stopPropagation();
        await switchJsonToolingModeByShortcut("mode2");
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, shortcuts.jsonToolingMarkdownTable)) {
        event.preventDefault();
        event.stopPropagation();
        await switchJsonToolingModeByShortcut("mode3");
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, shortcuts.copyCleanCodeBlock)) {
        event.preventDefault();
        event.stopPropagation();
        await runCleanCodeBlockCopy();
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, shortcuts.copyAsFetch)) {
        event.preventDefault();
        event.stopPropagation();
        await runHttpTransformCopy("fetch");
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, shortcuts.copyAsCurl)) {
        event.preventDefault();
        event.stopPropagation();
        await runHttpTransformCopy("curl");
        return;
      }
      if (doesKeyboardEventMatchShortcut(event, shortcuts.copyPageUrl)) {
        event.preventDefault();
        event.stopPropagation();
        await runPageCopy();
        return;
      }
    }
    function onStorageChanged(changes, areaName) {
      if (areaName !== "local") return;
      if (!changes.yank_settings) return;
      settingsState = mergeSettings(changes.yank_settings.newValue);
      syncModePill();
      helpMenu.update(buildHelpMenuData(settingsState));
    }
    function onJsonKeyClick(event) {
      if (!currentSettings().jsonTooling.decorateJsonBlocks) return;
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const keyElement = target.closest(".yank-json-key");
      if (!keyElement) return;
      const path = keyElement.dataset.yankPath;
      if (!path) return;
      event.preventDefault();
      event.stopPropagation();
      void writeClipboardText(path).then((ok) => {
        showToast(ok ? `Path copied: ${path}` : "Could not copy JSON path to clipboard. Keep this tab focused and try again.", {
          kind: ok ? "success" : "error"
        });
      });
    }
    function onSelectionChanged() {
      if (!currentSettings().autoCopy.enabled) return;
      scheduleAutoCopy();
    }
    async function bootstrap() {
      await refreshState();
      modePill = createModePill("");
      syncModePill();
      const keydownListener = (event) => {
        if (isEditableElement(event.target) && !event.altKey && !event.ctrlKey && !event.metaKey && !event.shiftKey) return;
        void keydownHandler(event).catch((error) => {
          closeTransientPanels();
          console.error("[Yank] key action failed", error);
          showToast("Action failed. Open panels were closed.", { kind: "error", dismissMs: 1700 });
        });
      };
      const pointerMoveListener = (event) => {
        pointerClientX = event.clientX;
        pointerClientY = event.clientY;
        hoveredCodeElement = closestCodeContainerFromNode(event.target);
      };
      const visibilityChangeListener = () => {
        if (document.visibilityState !== "visible") {
          closeTransientPanels();
        }
      };
      const pageHideListener = () => {
        closeTransientPanels();
      };
      const blurListener = () => {
        closeTransientPanels();
      };
      import_webextension_polyfill2.default.runtime.onMessage.addListener(handleRuntimeMessage);
      import_webextension_polyfill2.default.storage.onChanged.addListener(onStorageChanged);
      document.addEventListener("keydown", keydownListener, true);
      document.addEventListener("pointermove", pointerMoveListener, true);
      document.addEventListener("selectionchange", onSelectionChanged, true);
      document.addEventListener("copy", maybeTransformCopyEvent, true);
      document.addEventListener("click", onJsonKeyClick, true);
      document.addEventListener("visibilitychange", visibilityChangeListener, true);
      window.addEventListener("pagehide", pageHideListener, true);
      window.addEventListener("blur", blurListener, true);
      const mutationObserver = new MutationObserver(() => {
        if (currentSettings().jsonTooling.decorateJsonBlocks) {
          scheduleJsonBlockDecoration();
        }
      });
      mutationObserver.observe(document.documentElement, { childList: true, subtree: true });
      if (currentSettings().jsonTooling.decorateJsonBlocks) {
        scheduleJsonBlockDecoration();
      }
      await notifyContentReady();
      window.__yankCleanup = () => {
        modePill.destroy();
        helpMenu.destroy();
        if (autoCopyTimer != null) window.clearTimeout(autoCopyTimer);
        if (jsonDecorationTimer != null) window.clearTimeout(jsonDecorationTimer);
        import_webextension_polyfill2.default.runtime.onMessage.removeListener(handleRuntimeMessage);
        import_webextension_polyfill2.default.storage.onChanged.removeListener(onStorageChanged);
        mutationObserver.disconnect();
        document.removeEventListener("keydown", keydownListener, true);
        document.removeEventListener("pointermove", pointerMoveListener, true);
        document.removeEventListener("selectionchange", onSelectionChanged, true);
        document.removeEventListener("copy", maybeTransformCopyEvent, true);
        document.removeEventListener("click", onJsonKeyClick, true);
        document.removeEventListener("visibilitychange", visibilityChangeListener, true);
        window.removeEventListener("pagehide", pageHideListener, true);
        window.removeEventListener("blur", blurListener, true);
        if (document.documentElement.hasAttribute(INSTANCE_LOCK_ATTR)) {
          document.documentElement.removeAttribute(INSTANCE_LOCK_ATTR);
        }
      };
    }
    void bootstrap().catch((error) => {
      console.error("[Yank] content bootstrap failed", error);
    });
  }

  // src/entryPoints/contentScript/contentScript.ts
  initApp();
})();
