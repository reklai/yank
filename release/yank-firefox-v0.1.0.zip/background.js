"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/entryPoints/backgroundRuntime/background.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());

  // src/lib/backgroundRuntime/domains/yankDomain.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/lib/common/utils/shortcuts.ts
  var MODIFIER_ALIASES = {
    ctrl: "Ctrl",
    control: "Ctrl",
    alt: "Alt",
    option: "Alt",
    shift: "Shift",
    meta: "Meta",
    cmd: "Meta",
    command: "Meta",
    win: "Meta",
    super: "Meta"
  };
  var CANONICAL_SPECIAL_KEYS = {
    "`": "Backquote",
    backquote: "Backquote",
    enter: "Enter",
    return: "Enter",
    esc: "Escape",
    escape: "Escape",
    tab: "Tab",
    space: "Space",
    spacebar: "Space",
    arrowup: "ArrowUp",
    arrowdown: "ArrowDown",
    arrowleft: "ArrowLeft",
    arrowright: "ArrowRight",
    backspace: "Backspace",
    delete: "Delete",
    home: "Home",
    end: "End",
    pageup: "PageUp",
    pagedown: "PageDown",
    insert: "Insert"
  };
  function normalizeKeyToken(token) {
    const trimmed = token.trim();
    if (!trimmed) return null;
    const lower = trimmed.toLowerCase();
    if (lower in CANONICAL_SPECIAL_KEYS) {
      return CANONICAL_SPECIAL_KEYS[lower];
    }
    const fnKeyMatch = lower.match(/^f(\d{1,2})$/);
    if (fnKeyMatch) {
      const num = Number.parseInt(fnKeyMatch[1], 10);
      if (Number.isFinite(num) && num >= 1 && num <= 24) {
        return `F${num}`;
      }
    }
    const digitCodeMatch = lower.match(/^digit(\d)$/);
    if (digitCodeMatch) return digitCodeMatch[1];
    const keyCodeMatch = lower.match(/^key([a-z])$/);
    if (keyCodeMatch) return keyCodeMatch[1].toUpperCase();
    if (trimmed.length === 1) {
      if (/^[a-z]$/i.test(trimmed)) return trimmed.toUpperCase();
      return trimmed;
    }
    if (/^[a-z][a-z0-9]*$/i.test(trimmed)) {
      return trimmed[0].toUpperCase() + trimmed.slice(1);
    }
    return null;
  }
  function normalizeShortcutString(input) {
    const raw = input.trim();
    if (!raw) return "";
    const tokens = raw.split("+").map((token) => token.trim()).filter(Boolean);
    if (tokens.length === 0) return "";
    let keyToken = null;
    let ctrl = false;
    let alt = false;
    let shift = false;
    let meta = false;
    for (const token of tokens) {
      const lower = token.toLowerCase();
      const modifier = MODIFIER_ALIASES[lower];
      if (modifier) {
        if (modifier === "Ctrl") ctrl = true;
        if (modifier === "Alt") alt = true;
        if (modifier === "Shift") shift = true;
        if (modifier === "Meta") meta = true;
        continue;
      }
      const normalizedKey = normalizeKeyToken(token);
      if (!normalizedKey) return "";
      if (keyToken) return "";
      keyToken = normalizedKey;
    }
    if (!keyToken) return "";
    const output = [];
    if (ctrl) output.push("Ctrl");
    if (alt) output.push("Alt");
    if (shift) output.push("Shift");
    if (meta) output.push("Meta");
    output.push(keyToken);
    return output.join("+");
  }

  // src/lib/common/contracts/settings.ts
  var DEFAULT_SETTINGS = {
    urlCopy: {
      showToast: true,
      toastDismissMs: 1800
    },
    autoCopy: {
      enabled: false,
      plainTextMode: true,
      appendMode: false,
      sourceTagMode: false,
      siteRuleMode: "blacklist",
      siteRules: [],
      appendSeparator: "\n",
      showSelectionCountBadge: true
    },
    jsonTooling: {
      prettyPrintEnabled: false,
      tableFromArrayEnabled: false,
      decorateJsonBlocks: false,
      rootPathPrefix: "response.data"
    },
    shortcuts: {
      switchToAutoCopy: "Alt+T",
      jsonToolingPrettyPrint: "Alt+D",
      jsonToolingPathCopy: "Alt+Shift+D",
      jsonToolingMarkdownTable: "Alt+Shift+T",
      copyPageUrl: "Alt+C",
      copyCleanCodeBlock: "Alt+Shift+C",
      copyAsFetch: "Alt+F",
      copyAsCurl: "Alt+Shift+F"
    }
  };
  function cloneSettings(settings) {
    return JSON.parse(JSON.stringify(settings));
  }
  function normalizeJsonToolingSettings(settings) {
    const mode = settings.prettyPrintEnabled ? "mode1" : settings.decorateJsonBlocks ? "mode2" : settings.tableFromArrayEnabled ? "mode3" : "off";
    const rootPathPrefix = typeof settings.rootPathPrefix === "string" && settings.rootPathPrefix.trim() ? settings.rootPathPrefix : DEFAULT_SETTINGS.jsonTooling.rootPathPrefix;
    return {
      prettyPrintEnabled: mode === "mode1",
      decorateJsonBlocks: mode === "mode2",
      tableFromArrayEnabled: mode === "mode3",
      rootPathPrefix
    };
  }
  function mergeSettings(stored) {
    const merged = cloneSettings(DEFAULT_SETTINGS);
    if (!stored || typeof stored !== "object") {
      return merged;
    }
    if (stored.urlCopy) {
      merged.urlCopy = {
        ...merged.urlCopy,
        ...stored.urlCopy
      };
    }
    if (stored.autoCopy) {
      const next = {
        ...merged.autoCopy,
        ...stored.autoCopy
      };
      next.siteRules = Array.isArray(next.siteRules) ? next.siteRules.filter((value) => typeof value === "string") : [];
      merged.autoCopy = next;
    }
    if (stored.jsonTooling) {
      merged.jsonTooling = normalizeJsonToolingSettings({
        ...merged.jsonTooling,
        ...stored.jsonTooling
      });
    }
    if (stored.shortcuts && typeof stored.shortcuts === "object") {
      const incoming = {
        ...merged.shortcuts,
        ...stored.shortcuts
      };
      const keys = Object.keys(merged.shortcuts);
      const normalizedShortcuts = { ...merged.shortcuts };
      for (const key of keys) {
        const raw = incoming[key];
        if (typeof raw !== "string") {
          normalizedShortcuts[key] = merged.shortcuts[key];
          continue;
        }
        const trimmed = raw.trim();
        if (!trimmed) {
          normalizedShortcuts[key] = "";
          continue;
        }
        const normalized = normalizeShortcutString(trimmed);
        normalizedShortcuts[key] = normalized || merged.shortcuts[key];
      }
      merged.shortcuts = normalizedShortcuts;
    }
    return merged;
  }

  // src/lib/backgroundRuntime/domains/yankDomain.ts
  var STORAGE_SETTINGS_KEY = "yank_settings";
  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }
  var YankDomain = class {
    settings = clone(DEFAULT_SETTINGS);
    async init() {
      const stored = await import_webextension_polyfill.default.storage.local.get([STORAGE_SETTINGS_KEY]);
      this.settings = mergeSettings(stored[STORAGE_SETTINGS_KEY]);
    }
    async persistSettings() {
      await import_webextension_polyfill.default.storage.local.set({ [STORAGE_SETTINGS_KEY]: this.settings });
    }
    getSettings() {
      return clone(this.settings);
    }
    async patchSettings(patch) {
      this.settings = mergeSettings({
        ...this.settings,
        ...patch,
        urlCopy: { ...this.settings.urlCopy, ...patch.urlCopy || {} },
        autoCopy: { ...this.settings.autoCopy, ...patch.autoCopy || {} },
        jsonTooling: { ...this.settings.jsonTooling, ...patch.jsonTooling || {} },
        shortcuts: { ...this.settings.shortcuts, ...patch.shortcuts || {} }
      });
      await this.persistSettings();
    }
  };

  // src/lib/backgroundRuntime/handlers/commandRouter.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/backgroundRuntime/utils/contentScriptInjection.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var CONTENT_SCRIPT_FILE = "contentScript.js";
  var RETRY_DELAYS_MS = [0, 80, 180, 320];
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function getTabUrl(tab) {
    if (typeof tab.url === "string") return tab.url;
    const pending = tab.pendingUrl;
    return typeof pending === "string" ? pending : "";
  }
  function isInjectableTab(tab) {
    if (tab.id == null) return false;
    const url = getTabUrl(tab).toLowerCase();
    if (!url) return false;
    const blockedSchemes = [
      "about:",
      "chrome:",
      "chrome-extension:",
      "moz-extension:",
      "edge:",
      "resource:",
      "view-source:",
      "devtools:"
    ];
    for (const scheme of blockedSchemes) {
      if (url.startsWith(scheme)) return false;
    }
    return url.startsWith("http:") || url.startsWith("https:") || url.startsWith("file:");
  }
  async function injectContentScriptIntoTab(tabId) {
    try {
      try {
        await import_webextension_polyfill2.default.scripting.executeScript({
          target: { tabId },
          files: [CONTENT_SCRIPT_FILE]
        });
        return true;
      } catch {
        await import_webextension_polyfill2.default.tabs.executeScript(tabId, {
          file: CONTENT_SCRIPT_FILE,
          runAt: "document_idle"
        });
        return true;
      }
    } catch {
      return false;
    }
  }
  async function ensureContentScriptInjectedInOpenTabs() {
    const tabs = await import_webextension_polyfill2.default.tabs.query({});
    for (const tab of tabs) {
      if (!isInjectableTab(tab) || tab.id == null) continue;
      await injectContentScriptIntoTab(tab.id);
    }
  }
  async function sendMessageWithRetries(tabId, message) {
    for (const delay of RETRY_DELAYS_MS) {
      if (delay > 0) await sleep(delay);
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tabId, message);
        return true;
      } catch {
      }
    }
    return false;
  }
  async function sendMessageToActiveTabWithInjectionFallback(message) {
    const [activeTab] = await import_webextension_polyfill2.default.tabs.query({ active: true, currentWindow: true });
    if (!activeTab || activeTab.id == null) return false;
    if (await sendMessageWithRetries(activeTab.id, message)) {
      return true;
    }
    if (!isInjectableTab(activeTab)) {
      return false;
    }
    const injected = await injectContentScriptIntoTab(activeTab.id);
    if (!injected) return false;
    return sendMessageWithRetries(activeTab.id, message);
  }

  // src/lib/backgroundRuntime/handlers/commandRouter.ts
  function registerCommandRouter(_domain) {
    import_webextension_polyfill3.default.commands.onCommand.addListener(async (command) => {
      if (command === "copy-page-url") {
        await sendMessageToActiveTabWithInjectionFallback({ type: "RUN_COPY_PAGE_URL" });
      }
    });
  }

  // src/lib/backgroundRuntime/handlers/runtimeRouter.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());
  function registerRuntimeRouter(domain2, domainReady2) {
    import_webextension_polyfill4.default.runtime.onMessage.addListener(async (message) => {
      const runtimeMessage = message;
      try {
        await domainReady2;
        switch (runtimeMessage.type) {
          case "GET_SETTINGS":
            return { ok: true, settings: domain2.getSettings() };
          case "PATCH_SETTINGS":
            await domain2.patchSettings(runtimeMessage.patch);
            return { ok: true };
          case "CONTENT_READY":
            return { ok: true };
          default:
            return { ok: false, reason: "Unsupported runtime message." };
        }
      } catch (error) {
        return {
          ok: false,
          reason: error instanceof Error ? error.message : "Unknown runtime error"
        };
      }
    });
  }

  // src/entryPoints/backgroundRuntime/background.ts
  var domain = new YankDomain();
  var domainReady = domain.init();
  registerRuntimeRouter(domain, domainReady);
  registerCommandRouter(domain);
  function scheduleOpenTabsInjection(reason) {
    void domainReady.then(() => ensureContentScriptInjectedInOpenTabs()).catch((error) => {
      console.warn(`[Yank] content injection on ${reason} failed:`, error);
    });
  }
  import_webextension_polyfill5.default.runtime.onInstalled.addListener(() => {
    scheduleOpenTabsInjection("install");
  });
  import_webextension_polyfill5.default.runtime.onStartup.addListener(() => {
    scheduleOpenTabsInjection("startup");
  });
  void domainReady.catch((error) => {
    console.error("[Yank] Background bootstrap failed:", error);
  });
})();
